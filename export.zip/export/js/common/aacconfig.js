﻿
aac.config = {
    version: 0.5,
    top: { appkey: '12340690',
        appsecret: '657a6bd28c173fbd9b4e077ada55bfa1',
        sessionkeyurl: 'http://container.api.taobao.com/container?appkey=',
        format: 'json',
        version: '2.0',
        partner_id: 'top-apitools',
        apiurl: 'http://gw.api.taobao.com/router/rest?'
    },
    grid: {
        
    }
}