﻿/// <reference path="jquery-1.8.0.js" />
/// <reference path="base.js" />
/// <reference path="agent.base.js" />
/// <reference path="common/capture.js" /
/// <reference path="common/makePy.js" />

