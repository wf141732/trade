﻿/// <reference path="../jquery-1.7.2.js" />
/// <reference path="../common.js" />
/// <reference path="../common05.js" />
/// <reference path="../oeCommon.js" />
/// <reference path="../jqueryplugin/Jquery.Query.js" />


var oe = oe || window;

$(function () {
    zz.ini();
})
oe.zz = (function () {
    var o = $.extend(null, objMain, { tblMain: null }),
        content = '<tr class="{10}"><td class="oe-field-cell">{0}</td>' +
                  '<td class="oe-field-cell">{1}</td>' +
                  '<td class="oe-field-cell oe-number">{2}</td>' +
                  '<td class="oe-field-cell oe-number">{3}</td>' +
                  '<td class="oe-field-cell oe-number">{4}</td>' +
                  '<td class="oe-field-cell oe-number">{5}</td>' +
                  '<td class="oe-field-cell oe-number">{6}</td>' +
                  '<td class="oe-field-cell oe-number">{7}</td>' +
                  '<td class="oe-field-cell oe-number">{8}</td>' +
                  '<td class="oe-field-cell oe-number">{9}</td></tr>',
         zy = { '10qc': '本期期初', '20bq': '本期合计', '30bn': '本年累计' },
         period = null, account = null;
    function search(typeid) {
        var b = [], c = [];
        b.push(period.eq(0).attr('date_start'));
        b.push(period.eq(1).attr('date_stop'));
        b.push(account.eq(0).attr('code') || '0');
        b.push(account.eq(1).attr('code') || '9')
        $('input[name=account_level]:checked').each(function () {
            c.push($(this).val());
        })
        if (c.length) {
            b.push(' and a.level in (' + c.join(',') + ')');
        }
        else {
            b.push('');
        }
        if (typeid) {
            b.push(' and a.id in (select a.myid from account_zcfzb_type_rel r,(select id,id as myid from account_account where level=1 union all select parent_id,id from account_account where level=2) as a ' +
               ' where a.id=r.account_id and r.type_id=' + typeid + ')');
        }
        else {
            b.push('');
        }
        pgf.codeData('account.account.balance', b, function (a) {
            var trs = [], st = '', i = 0, stp = '', bqqc = 0, bnqc = 0;

            for (var i = 0, j = []; j = a[i]; i++) {
                j.push(f.price(j[2] + j[4], 2));
                j.push(f.price(j[3] + j[5], 2));
                j.push(i % 2 ? 'odd' : 'even');
                for (var k = 2; k < 10; k++) {
                    if (j[k]) {
                        j[k] = f.price(j[k], 2);
                    }
                }
                trs.push(formatStr(content, j));
            }

            $('.tblMain>tbody').html(trs.join(''));
            o.searchEnd();
        });
    };
    o.ini = function () {
        period = $('input[name=period_id]'), account = $('input[name=account_id]');
        period.each(function () { gAuto.period($(this)); });
        account.each(function () { gAuto.accountQ($(this)); });
        account.focus(function () {
            $(this).val($(this).attr('code'));
        }).blur(function () {
            $(this).val($(this).attr('title'));
        })
        $('.btnSearch').click(function () {
            search();
        });
        var type = jQuery.query.get('type');
        if (type == 'zcfzb') {
            var a = JSON.parse(decodeURI($.query.get('period')));
            period.val(a[1]);
            period.attr('date_start', a[2]);
            period.attr('date_stop', a[3]);
            search($.query.get('typeid'));
        }
        else {
            o.readyPeriod(period);
            //            pgf.codeData('account.period.now', [], function (a) {
            //                a = a[0];
            //                period.val(a[1]);
            //                period.attr('date_start', a[2]);
            //                period.attr('date_stop', a[3]);
            //            });
        }
    }
    return o;
})()