﻿/// <reference path="../jquery-1.7.2.js" />
/// <reference path="../common.js" />
/// <reference path="../common05.js" />
/// <reference path="../oeCommon.js" />
/// <reference path="../jqueryplugin/Jquery.Query.js" />
/// <reference path="../jquery.treeTable.js" />

var oe = oe || window;

$(function () {
    zz.ini();
})
oe.zz = (function () {
    var o = $.extend(null, objMain, { tblMain: null }),
        content = '<tr class="{8}"><td class="oe-field-cell">{0}</td>' +
                  '<td class="oe-field-cell">{1}</td>' +
                  '<td class="oe-field-cell">{2}</td>' +
                  '<td class="oe-field-cell oe-number">{3}</td>' +
                  '<td class="oe-field-cell oe-number">{4}</td>' +
                  '<td class="oe-field-cell">{5}</td>' +
                  '<td class="oe-field-cell oe-number">{6}</td></tr>',
         zy = { '-': '借', '+': '贷', '30bn': '本年累计' },
         accountContent = '<tr id="{0}" code="{1}" name="{2}" class="{3}" partner="{5}" analytic="{6}"><td class="oe-field-cell"><c>{1} {2}<c></td></tr>',
    period = null, account = null, tblAccount = null, analytic_level = null, partner = null, analytic = null;
    function search1(typeid) {
        var b = [], c = [];
        b.push(period.eq(0).attr('date_start'));
        b.push(period.eq(1).attr('date_stop'));
        //b.push(account.eq(0).attr('code') || '0');
        var c1=account.eq(0).attr('code'),c2=account.eq(1).attr('code');
        b.push(c1?c1.substr(0,4):'0')
        b.push((c2?c2.substr(0,4):'')+'9')
        $('input[name=account_level]:checked').each(function () {
            c.push($(this).val());
        })
        if (c.length) {
            b.push(' and a.level in (' + c.join(',') + ')');
        }
        else {
            b.push('');
        }
        if (typeid) {
            b.push(' and a.id in (select a.myid from account_zcfzb_type_rel r,(select id,id as myid from account_account where level=1 union all select parent_id,id from account_account where level=2) as a ' +
               ' where a.id=r.account_id and r.type_id=' + typeid + ')');
        }
        else {
            b.push('');
        }
        pgf.codeData('account.zz', b, function (a) {
            var tr = [], st = '', i = 0, stp = '', bqqc = 0, bnqc = 0;

            $(a).each(function () {
                if (this[0] != st) {
                    st = this[0];
                    if (this[3] != '10qc') {
                        var empty = [this[0], this[1], this[2], zy['10qc'], '', '', '', ''];
                        empty.push(i % 2 ? 'odd' : 'even');
                        tr.push(formatStr(content, empty));
                        i++;
                        this[0] = '';
                        this[1] = '';
                        bqqc = 0;
                        bnqc = 0;
                    }
                }
                else {
                    st = this[0];
                    this[0] = '';
                    this[1] = '';
                }
                this[8] = (i % 2 ? 'odd' : 'even');
                this[4] = f.price(this[4], 2);
                this[5] = f.price(this[5], 2);
                if (this[6] == '-') {
                    this[7] = (this[4] || 0) - (this[5] || 0);
                    this[6] = this[7] ? '借' : '平';
                }
                else {
                    this[7] = (this[5] || 0) - (this[4] || 0);
                    this[6] = this[7] ? '贷' : '平';
                }

                if (this[3] == '10qc') {
                    bqqc = this[7];
                    bnqc = this[7];
                }
                else if (this[3] == '20bq') {
                    this[7] = this[7] + bqqc;
                    bqqc = this[7];
                }
                else if (this[3] == '30bn') {
                    //this[7] = this[7] + bnqc;
                    null;
                    //bnqc = this[6];
                }
                this[7] = this[7] ? f.price(this[7], 2) : '';
                if ((!this[4] && !this[5]) || this[3] == '10qc') {
                    this[4] = '';
                    this[5] = '';
                    //this[7] = '';
                }
                this[3] = zy[this[3]];
                tr.push(formatStr(content, this));
                i++
            });
            $('.tblMain>tbody').html(tr.join(''));
            o.searchEnd();
        });
    };
    function where(partner, analytic) {
        var a = [];
        if (partner) {
            a.push(' and aml.partner_id=' + partner);
        }
        if (analytic) {
            a.push(String.format(' and aml.move_id in ( select move_id from account_voucher where analytic_id={0} union all ' +
			   ' select move_id from account_invoice ai,account_invoice_line ail where ail.invoice_id=ai.id and ail.account_analytic_id={0} )', analytic));
            //a.push(' and aml.move_id in (select move_id from account_voucher where analytic_id=' + analytic + ')');
        }
        if (a.length) {
            return a.join(' ');
        }
        else
            return '';
    }
    function getFx(sum, b) {
        var s = '';
        if (sum) {
            s = zy[b[5]];
        }
        else {
            s = '平';
        }
        return s;
    }
    function search(code, name, partner, analytic) {
        var t = [], a = [], y = 0, fi = 0;
        $('.label>c').text(name);
        a.push(code);
        a.push(period.eq(0).attr('date_start'));
        a.push(period.eq(1).attr('date_stop'));
        a.push(where(partner, analytic));
        pgf.codeData('account.mxb.mx', a, function (a) {
            for (var i = 0, b = []; b = a[i]; i++) {
                var type = b[6];
                if (b[5] == '-') {
                    b[6] = b[3] - b[4];
                }
                else {
                    b[6] = b[4] - b[3];
                }
                y += b[6];
                if (type == 'qc') {
                    b[3] = '';
                    b[4] = '';
                    fi = y;
                }
                if (type == 'bq') {
                    b[5] = getFx(fi + b[6], b);
                    b[6] = f.price(fi + b[6], 2);
                }
                else if (type == 'bn') {
                    b[5] = getFx(b[6], b);
                    b[6] = f.price(b[6], 2);
                }
                else {
                    b[5] = getFx(y, b);
                    b[6] = f.price(y, 2);
                }
                t.push(formatStr(content, b));
            }
            o.tblMain.find('>tbody').html(t.join(''));
            o.searchEnd();
        });
    }
    function searchAccount() {
        var c = [], b = [], t = [];
        $('input[name=account_level]:checked').each(function () {
            c.push($(this).val());
        })
        if (!c.length) {
            c = [1, 2]
        }
        b[0] = (' and level in (' + c.join(',') + ')');

        //b.push(account.eq(0).val() || 0);
        //b.push(account.eq(1).val() || 9);
        var c1 = account.eq(0).attr('code'), c2 = account.eq(1).attr('code');
        //b.push(c1 ? c1.substr(0, 4) : '0')
        //b.push((c2 ? c2.substr(0, 4) : '') + '9')
        b.push(c1 || 0);
        b.push(c2 || 9);

        //var partner = $('input[name=partner_id]');
        c = [1];
        analytic_level.each(function () {
            if ($(this).attr('checked'))
                c.push($(this).val());
        });
        b.push(c.join(','));
        var code = o.analytic_level == 2 ? 'account.mxb.account' : 'account.mxb.account.analytic';
        //b.push(partner.val() ? (' and rp.id =' + partner.attr('_id')) : '');
        //var code = analytic_level.attr('checked') ? 'account.mxb.account.partner' : 'account.mxb.account';
        pgf.codeData(code, b, function (a) {
            for (var i = 0, b = []; b = a[i]; i++) {
                if (b[4] == 2 || b[4] == 3) {//c.length > 1 &&
                    b[3] = 'child-of-' + b[3];
                }
                t.push(formatStr(accountContent, b));
            }
            tblAccount.find('>tbody').html(t.join('')).end().treeTable({ treeColumn: 0 }).find('tbody tr:eq(0)').click();
        })
    }
    function get() {
        var type = jQuery.query.get('type'); //从哪个地方点进来的
        if (type == 'zz') {
            var code = jQuery.query.get('code');
            var l = JSON.parse(decodeURI(jQuery.query.get('level')));
            var p = JSON.parse(decodeURI(jQuery.query.get('period')));
            account.val(code);
            period.eq(0).val(p[2]).attr('date_start', p[0]);
            period.eq(1).val(p[3]).attr('date_stop', p[1]);
            if (l.length == 2 || l.indexOf('2') > 0 || !l.length) {
                $('input[name=account_level]:eq(1)').attr('checked', 'checked');
            }
            var p = jQuery.query.get('partner');
            if (p) {
                p = partner.split('_');
                partner.val(p[0]).attr('_id', p[1]);
                analytic_level.eq(0).attr('checked', 'checked');
            }
            var a = jQuery.query.get('analytic');
            if (a) {
                a = a.split('_');
                analytic.val(a[1]).attr('_id', a[0]);
                analytic_level.eq(1).attr('checked', 'checked');
            }
            searchAccount();
            return true;
        }
        return false;
    }
    function print() {
        $('#printer .line').html($('.tblMain')[0].outerHTML);
        $('#printer .head table tr:eq(0) th:eq(0)').text($('.tblMain').prev().text());
        window.print();
    }
    o.ini = function () {
        period = $('input[name=period_id]'), account = $('input[name=account_id]');
        period.each(function () { gAuto.period($(this)); });
        account.each(function () { gAuto.accountQ($(this)); });
        analytic_level = $('input[name=analytic_level]').click(function () {
            if ($(this).attr('checked')) {
                if (!o.analytic_level) {
                    o.analytic_level = $(this).val();
                }
            }
            else {
                o.analytic_level = $('input[name=analytic_level]:checked').val();
            }
        }); //.eq(0).click(function () {
        //            if ($(this).attr('checked')) {
        //                $('input[name=account_level]').attr('checked', 'checked');
        //            }
        //        }).end();
        this.tblMain = $('.tblMain');
        partner = $('input[name=partner_id]');
        gAuto.co(partner, function () {
            if (partner.val()) {
                analytic_level.eq(0).attr('checked', 'checked');
            }
        });
        analytic = $('input[name=analytic_id]');
        gAuto.analytic(analytic, function () {
            if (analytic.val()) {
                analytic_level.eq(1).attr('checked', 'checked');
            }
        });
        tblAccount = $('.dvMain>.accountSelect table').find('>tbody>tr').live('click', function () {
            search($(this).attr('code'), $(this).attr('name'), $(this).attr('partner'), $(this).attr('analytic'));
        }).end();
        account.focus(function () {
            $(this).val($(this).attr('code'));
        }).blur(function () {
            $(this).val($(this).attr('title'));
        })
        $('.btnSearch').click(function () {
            searchAccount();
        });
        $('.btnPrint').click(function () {
            print();
        });
        if (!get()) {
            o.readyPeriod(period);
        }

    }
    return o;
})()
