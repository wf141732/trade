﻿/// <reference path="../jquery-1.7.2.js" />
/// <reference path="../common.js" />
/// <reference path="../common05.js" />
/// <reference path="../oeCommon.js" />


var objMain = { tbl: null, pager: null, ps: 80,cpg:0, searchEnd: function () {
    oeMessage.resize();
}
};

var oe = oe || window;
oe.pzSearch = (function () {
    var o = $.extend(null, objMain, { tblMain: null });

    function check() {
        var a = [], b = [];
        o.tbl.find('input:checkbox:checked:not(.all-record-selector)').each(function () {
            var id = $(this).parent().attr('value'), c = 0, d = 0, name = '';
            o.tblMain.find('>tbody>tr[data-id=' + id + ']').each(function () {
                var tds = $(this).find('td');
                c += parseFloat(tds.eq(5).text() || 0);
                d += parseFloat(tds.eq(6).text() || 0);
                name = name || tds.eq(0).text();
            });
            if (c != d) {
                //alert('此凭证不平衡');
                b.push(name);
                return;
            }
            a.push(id);
        });
        if (a.length && !b.length) {
            pgf.codeData('account.move.check', [user.id || 1, a.join(',')], function () {
                o.search();
                o.tblMain.find('.all-record-selector').removeAttr('checked');
            });
        }
        if (b.length) {
            alert('以下凭证不平衡：' + b.join(',') + '！');
        }
    }
    function deleteM(obj) { //删除凭证
        var tr = $(obj).parent().parent();
        if (tr.find('td[data-field=to_check]').text() != '未审核') {
            oeMessage.warn('凭证已审核');
            return;
        }
        else {
            pgf.codeData('account.move.delete', [tr.attr('data-id')], function () {
                o.search();
            })
        }
    }
    function uncheck() {
        var a = [], b = [];
        o.tblMain.find('input:checkbox:checked:not(.all-record-selector)').each(function () {
            var id = $(this).parent().attr('value');
            var tr = $(this).parent().parent();
            if (tr.attr('period-state') != 'draft') {
                alert('会计期' + tr.find('td[data-field=period_id]').text() + "已结帐");
                return;
            } else {
                a.push(id);
            }
        });
        if (a.length) {
            pgf.codeData('account.move.uncheck', [user.id || 1, a.join(',')], function () {
                o.search();
                o.tblMain.find('.all-record-selector').removeAttr('checked');
            });
        }
    }

    function print() {
        var doc = $(frames['printpz'].document).find('div');
        if (doc.find('table:hidden').size())
            doc.find('table:visible').remove();
        var table = doc.find('table').hide();
        o.tblMain.find('input:checkbox:checked:not(.all-record-selector)').each(function () {
            var t = table.clone().show(), trs = t.find('tr'),
                ymd = trs.eq(1).find('td'),
                md = ymd.find('span'),
                thisTds = $(this).parent().parent().find('td'),
                y = thisTds.eq(1).text(),
                m = y.split('/'), ctotal = 0, dtotal = 0, i = 4;
            ymd.prepend(m[0]);
            md.eq(0).append(m[1]);
            md.eq(1).append(m[2]);
            trs.eq(0).find('td:eq(3)').text(thisTds.eq(0).text());
            trs.eq(11).find('td:eq(5)').append(thisTds.eq(8).text());
            o.tblMain.find('tr[data-id=' + $(this).parent().attr('value') + ']').each(function () {
                var data = JSON.parse(decodeURI($(this).attr('data-head'))),
                    tds = trs.eq(i).find('td');
                if (data[14] || data[15]) {
                    ctotal += data[14];
                    dtotal += data[15];
                    tds.eq(0).text(data[27] || data[12]);
                    if (data[17] == 2) {
                        tds.eq(1).text(data[18]);
                        tds.eq(2).text(data[13]);
                    }
                    else {
                        tds.eq(1).text(data[13]);
                    }
                    var debit = f.price(data[15], 2).split('.'),
                        credit = f.price(data[14], 2).split('.');
                    i++;
                    if (data[15]) {
                        for (var l = debit[0].length, j = l - 1; j >= 0; j--) {
                            tds.eq(12 - j).text(debit[0][l - j - 1]);
                        }
                        tds.eq(13).text(debit[1][0]);
                        tds.eq(14).text(debit[1][1]);
                    }
                    if (data[14]) {
                        for (var l = credit[0].length, j = l - 1; j >= 0; j--) {
                            tds.eq(24 - j).text(credit[0][l - j - 1]);
                        }
                        tds.eq(25).text(credit[1][0]);
                        tds.eq(26).text(credit[1][1]);
                    }
                }
            });
            var total = trs.eq(10).find('td');
            if (dtotal) {
                dtoatal = f.price(dtotal, 2).split('.');
                for (var l = dtoatal[0].length, j = l - 1; j >= 0; j--) {
                    total.eq(10 - j).text(dtoatal[0][l - j - 1]);
                }
                total.eq(11).text(dtoatal[1][0]);
                total.eq(12).text(dtoatal[1][1]);
            }
            if (ctotal) {
                ctotal = f.price(ctotal, 2).split('.');
                for (var l = ctotal[0].length, j = l - 1; j >= 0; j--) {
                    total.eq(22 - j).text(ctotal[0][l - j - 1]);
                }
                total.eq(23).text(ctotal[1][0]);
                total.eq(24).text(ctotal[1][1]);
            }
            doc.append(t);
        });
        frames['printpz'].print();
    }
    function pagerState(obj) {
        var p = $(obj).attr('data-pager-action');
        if (p == 'first') {
            o.search(0);
        }
        else if (p == 'next') {
            o.search(o.cpg + 1);
        }
        else if (p == 'previous') {
            o.search(o.cpg - 1);
        }
        else if (p == 'last') {
            o.search(Math.ceil(o.total / o.ps) - 1);
        }
    }
    //重新整理凭证号
    function reseq() {
        pgf.codeData('account.move.reseq', [], function () {
            o.search();
        });
    }
    var thName = null;
    function changeSort(obj) {
        if (thName.attr('data-sort') == 'asc') {
            thName.attr('data-sort', 'desc');
        }
        else {
            thName.attr('data-sort', 'asc');
        }
    }
    o.ini = function () {
        if (!this.tbl) {
            var om = this;
            this.tbl = $('#tblSearch').find('.btnSearch').click(function () {
                om.search();
            }).end();
            this.tblMain = this.tbl.find('.oe-listview-content').find('.oe-record-edit-link').live('click', function () {
                om.tbl.hide();
                pzEdit.show(JSON.parse(decodeURI($(this).attr('data-head'))));
            }).end();
            thName = this.tblMain.find('th[data-id=name]').click(function () {
                changeSort(this);
                o.search(o.cpg);
            });
            this.tbl.find('.oe-list-add').click(function () {
                om.tbl.hide();
                pzEdit.show();
            });
            this.tbl.find('.oe-list-reseq').click(function () {//重新整理凭证号
                reseq();
            });
            this.tbl.find('input:checkbox').live('click', function () {
                if ($(this).attr('checked')) {
                    $('.all-record-selector').attr('checked', 'checked');
                    om.tbl.find('button.btnChecked').enable();
                }
                else {
                    if (om.tblMain.find('tbody input:checkbox:checked:not(.all-record-selector)').size() == 0) {
                        $('.all-record-selector').removeAttr('checked');
                        om.tblMain.find('button.btnChecked').disable();
                    }
                }
            });
            this.tblMain.find('.all-record-selector').click(function () {
                if ($(this).attr('checked'))
                    om.tblMain.find('input:checkbox').attr('checked', 'checked');
                else
                    om.tblMain.find('input:checkbox').removeAttr('checked');
            });
            this.tblMain.find('button[name=delete]').live('click', function () {
                deleteM(this);
            })
            this.tbl.find('button.oe-list-check').click(function () {
                check();
            });
            this.tbl.find('button.oe-list-uncheck').click(function () {
                uncheck();
            });
            this.tblMain.find('button.oe-list-print').click(function () {
                print();
            });
            this.tbl.find('.filter_label').click(function () {
                //om.tbl.find('.filter_label').removeClass('enabled');
                if ($(this).hasClass('enabled')) {
                    $(this).removeClass('enabled');
                }
                else {
                    $(this).addClass('enabled');
                }
                o.search();
            });
            gAuto.period(om.tbl.find('#period_id_00'));

            this.pager = this.tblMain.find('.oe-list-pager').find('button').click(function () {
                pagerState(this);
            }).end().find('span').click(function () {
                $(this).hide().next().show().val(o.ps);
            }).end().find('select').change(function () {
                o.ps = parseInt($(this).val());
                $(this).hide().prev().show();
                o.search();
            }).end();
        }
    }
    function getWhere() {
        var a = [], b = [], v;
        o.tbl.find('.filter_label.enabled').each(function () {
            a.push("'" + $(this).attr('value') + "'");
        });
        if (a.length) {
            b.push(' and am.to_check in ( ' + a.join(',') + ')');
        }
        v = o.tbl.find('#period_id_00').attr('_id');
        if (v) {
            b.push(' and am.period_id = ' + v);
        }
        n = o.tbl.find('#search_input_char_name_1024').val().toUpperCase();
        if (n) {
            b.push(" and am.name like '%" + n + "%' ");
        }
        r = o.tbl.find('#search_input_char_ref_1027').val().toUpperCase();
        if (r) {
            b.push(" and am.ref like '%" + r + "%'");
        }
        return b.join(' ');
    }
    function getSort() {
        return thName.attr('data-sort');
    }
    o.search = function (cpg) {
        if (cpg || cpg === 0) {
            pgf.codeData('account.move.query', [cpg * o.ps, o.ps ? (' limit ' + o.ps) : '', getWhere(), getSort()], function (a) {
                var c = [], s = -1, r;
                o.cpg = cpg;
                if (cpg < Math.ceil(o.total / o.ps) - 1) {
                    o.pager.find('button').eq(2).enable();
                    o.pager.find('button').eq(3).enable();
                }
                else {
                    o.pager.find('button').eq(2).disable();
                    o.pager.find('button').eq(3).disable();
                }
                if (cpg > 0) {
                    o.pager.find('button').eq(0).enable();
                    o.pager.find('button').eq(1).enable();
                }
                else {
                    o.pager.find('button').eq(0).disable();
                    o.pager.find('button').eq(1).disable();
                }
                //console.log(new Date());
                o.pager.find('span c:eq(0)').text(cpg * o.ps + 1);
                o.pager.find('span c:eq(1)').text((cpg + 1) * o.ps > o.total ? o.total : (cpg + 1) * o.ps);
                for (var i = 0, b; b = a[i]; i++) {
                    b[21] = (i % 2 ? 'odd' : 'even');
                    //b[3] = f.date(b[3]);       
                    r = o.fdata(b, s);
                    s = r.s;
                    c.push(r.tr);
                }
                o.tblMain.find('tbody.ui-widget-content').html(c.join(''));
                o.searchEnd();
                //console.log(new Date());
            });
        }
        else {
            pgf.codeData('account.move.count', ['', '', getWhere()], function (a) {
                if (a) {
                    o.total = a[0];
                    o.pager.find('span c:eq(2)').text(a[0]);
                    o.search(0);
                }
            });
        }
    }
    o.show = function () {
        this.search();
        this.tbl.show();
    }
    o.fdata = function (a, s) {//<td class="oe-field-cell" data-field="journal_id">{5}</td><td class="oe-field-cell" data-field="partner_id"></td>' +
        // '<td class="oe-field-cell oe-number" data-field="amount">{6}</td><input type="checkbox" disabled="disabled">
        var format = '<tr class="{21}" data-id="{0}" data-head="{22}" period-state="{26}" style="color: black;"><th class="oe-record-selector" width="1" value={0}>{23}</th>' +
                     '<th class="oe-record-edit-link" width="1" data-head="{22}">{24}</th>' +
                     '<td class="oe-field-cell" data-field="name">{1}</td><td class="oe-field-cell" data-field="date">{3}</td>' +
                     '<td class="oe-field-cell" data-field="period_id">{4}</td><td class="oe-field-cell">{12}</td><td class="oe-field-cell" data-field="account">{16} {13}</td><td class="oe-field-cell oe-number">{15}</td>' +
                     '<td class="oe-field-cell oe-number">{14}</td><td class="oe-field-cell" data-field="to_check">{19}</td>' +
                     '<td class="oe-field-cell" data-field="state" >{9}</td><td class="oe-field-cell">{20}</td><td class="oe-field-cell" data-field="ref">{2}</td><td class="oe-field-cell oe-button" data-field="button_validate"></td><td class="oe-record-delete" width="1">' +
                     '{25}</td></tr>';
        a[22] = (encodeURI(JSON.stringify(a)));
        a[23] = '<input name="radiogroup" type="checkbox">';
        a[24] = '<img class="oe-record-edit-link-img" height="12" src="/web/static/src/img/pencil.gif" width="12">';
        //a[24] = '<img class="oe-record-edit-link-img" height="12" src="/img/tbtn_new.gif" title="新增行" width="12">';
        a[25] = a[19] ? '' : '<button name="delete" type="button"></button>';
        //a[25] = '<button name="delete" type="button"></button>';
        a[13] = a[17] == 2 ? (a[18] + '_' + a[13]) : a[13];
        a[14] = a[14] ? f.price(a[14], 2) : '';
        a[15] = a[15] ? f.price(a[15], 2) : '';
        a[20] = a[19] ? a[20] : '';
        a[19] = a[19] ? '已审核' : '未审核';
        if (s == a[0]) {
            a[9] = '';
            a[19] = '';
            a[20] = '';
            a[23] = '';
            a[24] = '';
            a[25] = '';
            a[1] = '';
            a[3] = '';
            a[4] = '';
            a[2] = '';
        }
        else {
            s = a[0];
        }
        //return format;
        return { tr: String.format.apply(null, [format].concat(a)), s: s };
    }
    return o;
})();

oe.pzEdit = (function () {
    var o = $.extend(null, objMain, { tblMain: null }), emptyLine = ['', '', '', '', '', '', '', '', '', '', '', ''];
    var format = '<tr class="{8}" data_id="{0}"><th class="oe-record-edit-link">{9}</th><td>{1}</td><td>{2} {3}</td><td>{5}</td><td>{6}</td><td>{7}</td>' +
                    '<td class="oe-record-delete"><button type="button" style="visibility: hidden"></button></td></tr>',
    // btnAdd = '<img class="oe-record-edit-link-img" height="12" src="/web/static/src/img/pencil.gif" width="12">';
                   btnAdd = '<img class="oe-record-edit-link-img" height="12" src="/img/tbtn_new.gif" title="新增行" width="12">';

    fdataHead = function (a) {
        var n = o.tblHead.find('input'); //.each(function (i) {
        //    $(this).val(a[i]);
        //})
        n.eq(0).val(a[0]).attr('journal_id', a[11]);
        n.eq(1).val(a[1]).attr('_id', a[0]?0:a[12]).attr('p_id', a[10]); //name
        n.eq(2).val(a[2]);
        n.eq(3).val(a[3]); //date
        n.eq(4).val(a[4]).attr('_id', a[10]); //period
        n.eq(5).val(a[8]); //proof
        n.eq(6).val(a[9]);
    }
    fdataLine = function (a) {
        //return String.format.apply(null, [format].concat(a));
        var format = '<tr class="{8}" data_id="{0}" account_id="{9}" analytic_account="{10}"><th class="oe-record-edit-link" width="1">{11}</th><td class="oe_form_frame_cell oe_form_field_char formview_false_field_name_char_1 oe-field-cell">' +
                     '<input size="1" style="width: 100%;" name="name" type="text" class="field_char" value="{1}"></td><td class="oe_form_frame_cell oe_form_field_many2one" data-field="account_id">' +
                     '<table border="0" cellpadding="0" cellspacing="0" width="100%"><tbody><tr><td valign="top" width="100%"><input size="1" style="width: 100%" name="account_id" value="{2} {3}" code="{2}" title="{2} {3}" type="text" class="field_many2one">' +
                     '<span class="oe-m2o-drop-down-button"><img src="/web/static/src/img/down-arrow.png"></span></td><td><button class="oe_button oe_field_button oe-m2o-cm-button"><img src="/web/static/src/img/icons/STOCK_DIRECTORY_MENU.png">' +
                     '</button></td></tr></tbody></table></td><td class="oe_form_frame_cell oe_form_field_float oe-field-cell">' +
                     '<input size="1" style="width: 100%;" name="debit" type="text" value="{5}" class="field_float oe-number debite"></td><td class="oe_form_frame_cell oe_form_field_float oe-field-cell">' +
                     '<input size="1" style="width: 100%;" name="credit" type="text" value="{6}" class="field_float oe-number credit"></td><td class="oe-record-delete" width="1"><button name="delete" type="button"></button></td></tr>';
        //<td class="oe_form_frame_cell oe_form_field_many2one oe-field-cell">' +
        //'<table border="0" cellpadding="0" cellspacing="0" width="100%"><tbody><tr><td valign="top" width="100%"><input size="1" style="width: 100%" value="{7}" name="analytic_account_id" type="text" class="field_many2one">' +
        //'<span class="oe-m2o-drop-down-button"><img src="/web/static/src/img/down-arrow.png"></span></td><td><button class="oe_button oe_field_button oe-m2o-cm-button">' +
        //'<img src="/web/static/src/img/icons/STOCK_DIRECTORY_MENU.png"></button></td></tr></tbody></table></td>
        for (var i = 0; i < a.length; i++) {
            a[i] = a[i] || '';
        }
        a[11] = a[11] || btnAdd;
        return String.format.apply(null, [format].concat(a));
    }
    addLine = function (obj) {
        var i = null;
        if (obj) {
            i = $(fdataLine(emptyLine)).insertBefore(o.tbl.find('.tblLine>tbody>tr').has(obj));
        }
        else {
            i = $(fdataLine(emptyLine)).appendTo(o.tbl.find('.tblLine > tbody'));
        }
        autoAccount(i.find('input[name=account_id]'));
        lineResort();
        return i;
    }
    autoAccount = function (obj) {
        gAuto.account($(obj), function (data, target) {
            var i = o.tbl.find('.tblLine > tbody > tr:visible').has(target);
            i.attr('account_id', data.id);
            //i.children().has(obj).next().find('input').focus();
        });
    }
    lineResort = function () {//重新给tr添加元素
        o.tbl.find('.tblLine > tbody > tr:visible').each(function (i) {
            $(this).removeClass().addClass(i % 2 ? 'odd' : 'even');
        });
    }
    total = function (obj) { //计算借代双方的合计
        var c = 0, d = 0;
        o.tbl.find('.tblLine > tbody >tr').each(function () {
            if (obj && $(this).has(obj).size()) {
                null;
            }
            else {
                $(this).find('input[name=credit]').each(function () {
                    c += parseFloat($(this).val()) || 0;
                });
                $(this).find('input[name=debit]').each(function () {
                    d += parseFloat($(this).val()) || 0;
                });
            }
        });

        o.tbl.find('.tblLine>tfoot>tr>td.credit').text(c);
        o.tbl.find('.tblLine>tfoot>tr>td.debit').text(d);
        o.tbl.find('.tblLine>tfoot>tr>td.chineseNumber').text(c == d ? DX(c) : '');
        return c - d;
    };
    save = function (obj) {//保存
        var n = o.tblHead.find('input'), a = [], update = [], c = [], insert = [], del = [];
        //a.push(n.eq(0).val());
        a.push(o.id);
        a.push(user.id || 1);
        a.push(n.eq(1).val()); //name
        a.push(n.eq(0).attr('journal_id'));
        a.push(n.eq(4).attr('_id')); //period
        a.push(n.eq(3).val()); //date
        a.push(n.eq(5).val()); //proof
        a.push(n.eq(1).attr('_id') || -1);
        if (o.tbl.find('.tblLine>tfoot>tr>td.credit').text() != o.tbl.find('.tblLine>tfoot>tr>td.debit').text()) {
            oeMessage.warn('借贷双方不平衡');
            return;
        }
        o.tbl.find('.tblLine >tbody >tr:visible').each(function () {
            c = [];
            c.push($(this).attr('data_id'));
            c.push(user.id || 1);
            c.push($(this).attr('account_id'));
            c.push(a[3]); //journal_id
            c.push($(this).attr('analytic_account'));
            c.push(a[4]);
            c.push(''); //move_id 6
            $(this).find('input').each(function () {
                c.push($(this).val());
            })
            c[4] = c[4] || 'null';
            c[9] = c[9] || 0;
            c[10] = c[10] || 0;
            if (c[7] && c[8] && (c[9] || c[10]))//6account 9analytic
                c[0] ? update.push(c) : insert.push(c);
        })
        if (insert.length + update.length > 0) {
            $(obj).text('正在保存...').disable();
            pgf.codeData(a[0] ? 'pzUpdateHead' : 'pzInsertHead', a, function (b) {
                var j = 0;
                if (update.length) {
                    for (var i = 0; i < update.length; i++) {
                        update[i][6] = b[0];
                    }
                    j++;
                    pgf.batchUpdate('pzUpdateLine', update, function () {
                        j--;
                        if (j == 0) {
                            $(obj).text('保存').enable();
                        }
                    });
                }
                if (insert.length) {
                    for (var i = 0; i < insert.length; i++) {
                        insert[i][6] = b[0];
                    }
                    j++;
                    pgf.batchUpdate('pzInsertLine', insert, function () {
                        j--;
                        if (j == 0) {
                            $(obj).text('保存').enable();
                        }
                    });
                }
            });
        }
        else {
            oeMessage.show('有效凭证分录不足！');
        }
    }
    o.ini = function () {
        if (!this.tbl) {
            var om = this;
            this.tbl = $('#tblEdit').find('.oe_vm_switch_list').click(function () {//查看列表
                pzSearch.show();
                om.tbl.hide();
            }).end().find('.oe_form_button_save').click(function () {
                save(this);
            }).end();
            this.tblHead = this.tbl.find('.tblHead');
            var moveName = this.tblHead.find('input[name=name]');
            gAuto.pzNameP(moveName); //凭证号
            gAuto.periodM(this.tblHead.find('input[name=period_id]'), function (c) {
                moveName.val(c.move_name).attr('_id', c.sequence_id);
            });
            //this.tblLine = this.tbl.find('.tblLine');
            this.tbl.find('.tblLine input[name=name]').live('blur', function () {
                o.lineName = $(this).val().trim();
            }).live('focus', function () {
                $(this).val($(this).val().trim() || o.lineName);
            });
            this.tbl.find('.tblLine input[name=account_id]').live('blur', function () {
                $(this).val($(this).attr('title'));
            }).live('focus', function () {
                $(this).val($(this).attr('code'));
            });
            this.tbl.find('.tblLine button.oe-list-add').click(function () {//添加行
                addLine();
            });
            this.tbl.find('.tblLine th.oe-record-edit-link').live('click', function () {
                addLine(this);
            })
            this.tbl.find('.tblLine button[name=delete]').live('click', function () {//删除行
                var n = om.tbl.find('.tblLine > tbody > tr').has(this)
                if (n.attr('data_id'))
                    n.hide();
                else
                    n.remove();
                lineResort();
            });
            this.tbl.find('.tblLine input[name=debit]').live('blur', function () {
                if ($.isNumeric($(this).val()) || !$(this).val()) {
                    $(this).val(parseFloat($(this).val()) || '');
                    total();
                }
                else {
                    $(this).val('').focus();
                }
            }).live('focus', function () {
                var n = om.tbl.find('.tblLine >tbody > tr').has(this), i;
                if (n.find('input[name=credit]').val() > 0) {
                    n = n.find('input');
                    i = jQuery.inArray(this, n);
                    n.eq(i + 1).focus();
                    return false;
                }
            });
            this.tbl.find('.tblLine input[name=credit]').live('blur', function () {
                if ($.isNumeric($(this).val()) || !$(this).val()) {
                    $(this).val(parseFloat($(this).val()) || '');
                    total();
                }
                else {
                    $(this).val('').focus();
                }
            }).live('focus', function () {
                var n = om.tbl.find('.tblLine >tbody > tr').has(this), i;
                if (n.find('input[name=debit]').val() > 0) {
                    n = n.find('input');
                    i = jQuery.inArray(this, n);
                    n.eq(i + 1).focus();
                    return false;
                }
            });
            this.tbl.find('.tblLine input').live('keyup', function (evt) {
                o.lineName = $(this).attr('name') == 'name' ? $(this).val() : o.lineName;
                var keyCode = evt.keyCode, n;
                if (keyCode == 13)//enter
                {
                    n = om.tbl.find('.tblLine > tbody > tr').has(this).next();
                    if (!n.size())
                        n = addLine();
                    n.find('input[name=' + evt.target.name + ']').focus();
                }
                if (keyCode == 9) {//tab
                    n = om.tbl.find('.tblLine > tbody > tr').has(this).find('input:text');
                    // n = om.tbl.find('.tblLine > tbody > tr').has(this).find('input').has(this).next();
                    var i = jQuery.inArray(this, n);
                    n.eq(i + 1).focus();
                    if (!n.eq(i + 1).size()) {
                        n = om.tbl.find('.tblLine > tbody > tr').has(this).next();
                        if (!n.size()) {
                            n = addLine();
                        };
                        n.find('input:eq(0)').focus();
                    }
                    return false;
                };
                if ((keyCode == 187 || keyCode==229) && (evt.target.name == 'debit' || evt.target.name == 'credit')) {//输入等号
                    var n = total(this);
                    if (n > 0) {
                        om.tbl.find('.tblLine > tbody > tr').has(this).find('input[name=debit]').val(Math.abs(n)).focus();
                    }
                    else if (n < 0)
                        om.tbl.find('.tblLine > tbody > tr').has(this).find('input[name=credit]').val(Math.abs(n)).focus();
                    return false;
                }
            });

            this.tbl.find('.oe_form_button_copy').click(function () {
                om.tbl.find('input,button:not(.oe_vm_switch button)').enable();
                pgf.codeData('pzCode', [], function (a) {
                    o.tblHead.find('input:eq(1)').val(a[0][0]);
                })
                o.id = null;
            });

            this.tbl.find('.oe_form_button_add').click(function () {
                o.show();
            })
        }
    }
    o.show = function (a) {
        this.ini();
        var om = this, checked;
        if (a) {
            fdataHead(a);
            om.id = a[0];
            checked = a[19];
            if (checked) {
                om.tbl.find('input,button:not(.oe_vm_switch button)').disable();
            }
            else {
                om.tbl.find('input,button:not(.oe_vm_switch button)').enable();
            }
            om.tbl.find('button.oe_form_button_copy,button.oe_form_button_add').enable();
            pgf.codeData('account.move.line.query', [a[0]], function (b) {
                a = [];
                var l = b.length, i = 0;
                for (var c; c = b[i]; i++) {
                    c[3] = c[8] == 1 ? (c[4] + '_' + c[3]) : c[3];
                    //                    c[8] = i % 2 ? 'odd' : 'even';
                    //                    c[11] = btnAdd;
                    a.push(fdataLine(c));
                }
                b = emptyLine;
                for (; 8 - i > 0; i++) {
                    a.push(fdataLine(b));
                }
                var o = om.tbl.find('.tblLine > tbody').html(a.join(''));
                o.find('input[name=account_id]').each(function () {
                    autoAccount(this);
                });
                total();
                om.tbl.show();
            })
        }
        else {
            pgf.codeData('account.move.name', [], function (a) {
                a = a[0];
                om.tbl.find('input,button:not(.oe_vm_switch button)').enable();
                fdataHead(['', a[0], '', a[1], a[3], , '', '', '1', user.name || user.login, a[2], a[4], a[5]]);
                var a = [], b = ['', '', '', '', '', '', '', '', '', '', '', '', ''];
                for (var i = 0; 8 - i > 0; i++) {
                    //                    b[8] = i % 2 ? 'odd' : 'even';
                    //                    b[11] = btnAdd;
                    a.push(fdataLine(b));
                }
                var o = om.tbl.find('.tblLine > tbody').html(a.join(''));
                o.find('input[name=account_id]').each(function () {
                    autoAccount(this);
                });
                total();
                om.tbl.show();
            })
        }
    }
    return o;
})()

$(function () {
    pzSearch.ini();
})