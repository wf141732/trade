﻿/// <reference path="../jquery-1.7.2.js" />
/// <reference path="../common.js" />
/// <reference path="../common05.js" />
/// <reference path="../oeCommon.js" />
/// <reference path="../jquery.treeTable.js" />

var oe = oe || window;
$(function () {
    qc.ini();
});

oe.qc = (function () {
    var o = $.extend(null, objMain, { tblMain: null }),
        typeContent = '<li data-id="{0}" class="ui-state-default ui-corner-top"><a href="#" data-id="{0}">{2}</a></li>',
        content = '<tr id="{3}" data-id="{0}" parent="{4}" ref="{10}" fx="{12}" account_id="{3}" partner="{11}" class="{4} {14}"><th class="oe-record-edit-link" width="1"></th>' +
                  '<td class="oe-field-cell" data-field="name" width="40%">{2}{1}</td>' +
                   '<td class="oe-field-cell" data-field="name" width="10%">{13}</td>' +
                  '<td class="oe-number oe-field-cell" data-field="qty">{7}</td>' +
                  '<td class="oe_form_frame_cell oe_form_field_float oe-field-cell"><input size="1" style="width: 100%;height:100%" name="debit" type="text" value="{5}" v="{5}" class="field_float oe-number debite"></td>' +
    // '<td class="oe_form_frame_cell oe_form_field_float oe-field-cell"><input size="1" style="width: 100%;height:100%" name="credit" type="text" value="{6}" val="{6}" class="field_float oe-number credit"></td>' +
                  '<td class="oe-record-delete" width="1"><button name="delete" type="button"></button></td></tr>';
    function save(obj) {
        var update = [], insert = [], a = [], text = $(obj).text();
        $(obj).text('正在处理..').disable();
        if (o.id) {
            o.tblMain.find('tr.dirty').each(function () {
                a = [];
                var debit = $(this).find('input[name=debit]').val(), fx = $(this).attr('fx'), credit = null;
                if ((fx == '+' && debit > 0) || (fx == '-' && debit < 0)) { //+(贷-借)
                    credit = Math.abs(debit);
                    debit = 0;
                }
                else {
                    debit = Math.abs(debit);
                }
                //                else if (fx == '+' && debit < 0) {
                //                    debit = debit;
                //                }
                //                else if (fx == '-' && debit > 0) {
                //                    debit = debit;
                //                }
                //                else if (fx == '-' && debit < 0) {
                //                    credit = debit;
                //                }
                if ($(this).attr('data-id')) {
                    a.push($(this).attr('data-id'));
                    a.push(debit || 0);
                    a.push(credit || 0);
                    update.push(a);
                }
                else {
                    a.push(-1);
                    a.push(user.id || 1); //1
                    var account_id = $(this).attr('account_id');
                    if (account_id < 0) {
                        account_id = $(this).attr('parent').substr(9);
                    }
                    a.push(account_id);
                    a.push(o.journal_id);
                    a.push($(this).attr('analytic_account_id') || 'null'); //4
                    a.push(-1);
                    a.push(o.id);
                    a.push('期初'); //7
                    a.push(-1); //
                    a.push(debit || 0);
                    a.push(credit || 0); //10
                    a.push($(this).attr('partner') || 'null');
                    insert.push(a);
                }
            })
            if (insert.length > 0) {
                pgf.batchUpdate('account.move.line.insert', insert, function (a) {
                    console.log(a);
                    $('.btnClose').enable();
                    $(obj).text(text).enable();
                });
            }
            if (update.length > 0) {
                pgf.batchUpdate('account.move.line.update', update, function (a) {
                    console.log(a);
                    $('.btnClose').enable();
                    $(obj).text(text).enable();
                });
            }
        }
    }
    var createIniPz = function () { //创建期初凭证

    }
    function getJournal(success) {
        pgf.codeData('account.ini.journal', [], function (a) {//查找期初账簿
            if (a && a[0]) {
                o.journal_id = a[0];
                success();
            }
            else {
                oeMessage.warn('未建立期初账簿');
            }
        });
    }
    function getPeriod(success) {
        pgf.codeData('account.ini.period', [], function (a) { //期初会计期
            if (a && a[0]) {
                o.period_id = a[0];
                success();
            }
            else {
                oeMessage.warn('未建立期初会计期');
            }
        })
    }
    function getType(ul, success) {//获取科目分类
        pgf.codeData('account.china.type', [], function (a) {
            var c = [];
            for (var i = 0, b = []; b = a[i]; i++) {
                c.push(formatStr(typeContent, b));
            }
            //om.tblMain.find('>tbody').remove(); //.addClass('type'+a[0][0]);
            ul.html(c.join('')).find('li').eq(0).end(); //.click().end();
            success();
        })
    }
    function fdata(a, typeid) {
        var c = [], i = 0, b = [], om = o;
        for (; b = a[i]; i++) {
            b[4] = b[4] ? ('child-of-' + b[4]) : '';
            b[2] = b[2] + '_';
            if (b[12] == '-') {
                b.push('借');
                b[5] = b[5] - b[6];
            }
            else {
                b.push('贷');
                b[5] = b[6] - b[5];
            }
            b[5] = f.price(b[5], 2);
            b[7] = f.price(b[7], 2);
            b.push((i % 2 ? 'odd' : 'even'));
            c.push(formatStr(content, b));
        }
        for (; i < 6; i++) {
            b = ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''];
            b[14] = ((i % 2 ? 'odd' : 'even'));
            c.push(formatStr(content, b));
        }
        om.tblMain.find('>tbody').hide();
        if (om.tblMain.find('>tbody.type' + typeid).size()) {
            om.tblMain.find('>tbody.type' + typeid).show();
            //om.tblMain.append('<tbody class=type' + typeid + '>' + c.join('') + '<tbody/>').treeTable({ treeColumn: 0 });
        }
        else {
            om.tblMain.append('<tbody class=type' + typeid + '>' + c.join('') + '<tbody/>')
            om.tblMain.treeTable({ treeColumn: 0, onNodeShow: function () {
                o.searchEnd();
            }, onNodeHide: function () {
                o.searchEnd();
            }
            });
            o.searchEnd();
            //            $(om.tblMain).expand(function () {

            //            }).collapse(function () {
            //                o.searchEnd();
            //            })
        }
    }
    function total() {
        var c = 0; d = 0, q = 0;
        o.tblMain.find('tbody:visible>tr').each(function () {//当前现实的tbody
            if (!$(this).attr('parent')) {
                c += parseFloat($(this).find('[name=credit]').val() || 0);
                d += parseFloat($(this).find('[name=debit]').val() || 0);
                q += parseFloat($(this).find('td:eq(2)').text() || 0);
            }
        });
        o.tblMain.find('>tfoot>tr').find('.credit').text(f.price(c, 2)).end().find('.debit').text(f.price(d, 2)).end().find('.qty').text(f.price(q, 2));
    }
    function typeSelected(obj, code, id, qcid) {
        $(obj).parent().find('li').removeClass('ui-tabs-selected').removeClass('ui-state-active');
        $(obj).addClass('ui-tabs-selected').addClass('ui-state-active');
        //var om = this
        var typeid = $(obj).attr('data-id');
        var a = [typeid, id];
        if (qcid) a.push(qcid);
        if (!o.inventory_id) return;
        pgf.codeData(code, a, function (a) {
            fdata(a, typeid);
            o.tblMain.find('>tbody:visible>tr').has('a').each(function () {
                var trp = $(this), credit = 0, debit = 0, qty = 0;
                //$(this).find('[name=credit]').val(0).end().find('[name=debit]').val(0);
                o.tblMain.find('tbody:visible').find('.child-of-' + $(this).attr('id')).each(function () {
                    credit += parseFloat($(this).find('[name=credit]').val() || 0);
                    debit += parseFloat($(this).find('[name=debit]').val() || 0);
                })
                $(this).find('[name=credit]').val(f.price(credit, 2)).end().find('[name=debit]').val(f.price(debit, 2));
            }).find('input').disable();
            o.tblMain.find('>tbody>tr[ref|=]').find('input').disable();
            total();
            //            var c = 0; d = 0, q = 0;
            //            o.tblMain.find('tbody:visible>tr').each(function () {//当前现实的tbody
            //                if (!$(this).attr('parent')) {
            //                    c += parseFloat($(this).find('[name=credit]').val() || 0);
            //                    d += parseFloat($(this).find('[name=debit]').val() || 0);
            //                    q += parseFloat($(this).find('td:eq(2)').text() || 0);
            //                }
            //            });
            //            o.tblMain.find('>tfoot>tr').find('.credit').text(f.price(c, 2)).end().find('.debit').text(f.price(d, 2)).end().find('.qty').text(f.price(q, 2));
            //om.tblMain.find('>tbody').html(c.join('')).end().treeTable({ treeColumn: 0 });
        });
    }
    function qInventory() {
        gAuto.inventory($('input[name=inventory_id]'), function (a) {
            o.inventory_id = a.id
        });
    }
    function pzSearch(ul) {
        pgf.codeData('account.ini.pz.query', [], function (a) { //查询期初凭证行
            if (a && a[0]) {
                a = a[0];
                o.id = a[0];
                o.inventory_id = a[3];
                $('input[name=inventory_id]').val(a[2]).attr('_id', a[3]).disable();
                $('.btnSearch,.btnConfirm').disable();
                ul.find('li').live('click', function () {
                    typeSelected(this, 'account.ini.pz.line.query', a[0]);
                }).eq(0).click();
                $('.btnClose').disable();
                if (a[4]) {
                    $('.oe_search-view-buttons button').disable();
                }
                //                pgf.codeData('account.ini.pz.line.query', [a[0]], function (a) { //查询期初凭证
                //                    fdata(a, 1);
                //                });
            }
            else {
                qInventory();
                $('.btnClose').enable();
                ul.find('li').live('click', function () {
                    typeSelected(this, 'account.ini.qc', o.inventory_id, a.id || -1);
                }).eq(0).click();
            }
        })
    }
    function close() {
        var a = [];
        a.push(o.id);
        a.push(user.id || 1);
        pgf.codeData('account.ini.close', a, function () {
            $('.oe_search-view-buttons button').disable();
        });
    }
    o.ini = function () {
        var om = this;
        this.tblMain = $('.tblMain');
        var ul = $('.china-type>ul');
        getType(ul, function () { pzSearch(ul) });
        this.tblMain.find('input').live('blur', function () {//失焦
            if ($(this).val() != $(this).attr('v')) {
                var tr = om.tblMain.find('>tbody>tr').has(this);
                tr.addClass('dirty');
                if (tr.attr('parent'));
                {
                    var p = $('#' + tr.attr('parent').substr(9)).find('[name=' + $(this).attr('name') + ']');
                    p.val(f.price(parseFloat(p.val() || 0) + parseFloat($(this).val() || 0) - parseFloat($(this).attr('v') || 0), 2));
                    $(this).attr('v', $(this).val());
                    total();
                }
            }
        }).live('keydown', function (evt) {
            var keyCode = evt.keyCode, n;
            if (keyCode == 13)//enter
            {
                n = om.tblMain.find('> tbody > tr').has(this).next();
                n.find('input[name=' + evt.target.name + ']').focus();
                total();
            }
        });

        $('.btnReSelect').click(function () {
            $('input[name=inventory_id]').enable();
            ul.find('li').die().live('click', function () {
                typeSelected(this, 'account.ini.qc', o.inventory_id, o.id || -1);
            });
            qInventory();
            $('.btnSearch,.btnConfirm').enable();
        });

        $('.btnSearch').click(function () {
            getJournal(function () {
                getPeriod(function () {
                    om.tblMain.find('>tbody').remove();
                    ul.find('li').eq(0).click();
                })
            })

        });

        $('.btnConfirm').click(function () {//确认盘点单，建立期初凭证
            var a = [], code = '';
            a.push(user.id || 1); //0
            a.push('期初' + (new Date()).getFullYear());
            a.push(o.journal_id);
            a.push(o.period_id); //3
            a.push(gf.dateFormat(Date(), 'yyyy-MM-dd'));
            a.push(o.inventory_id);
            a.push(o.id);
            code = o.id ? 'account.ini.pd.change' : 'account.ini.pz';
            pgf.codeData(code, a, function (b) {
                o.id = b[0];
            });
        });

        $('.btnSave').click(function () {
            save(this);
        })

        $('.btnClose').click(function () {
            close();
        });
    }
    return o;
})();