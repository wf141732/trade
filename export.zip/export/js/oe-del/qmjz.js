﻿/// <reference path="../jquery-1.7.2.js" />
/// <reference path="../common.js" />
/// <reference path="../common05.js" />
/// <reference path="../oeCommon.js" />

var oe = oe || window;
oe.pzSearch = (function () {
    var o = $.extend(null, objMain, { tblMain: null }), period;

    function check() {
        var a = [], b = [];
        o.tbl.find('input:checkbox:checked:not(.all-record-selector)').each(function () {
            var id = $(this).parent().attr('value'), c = 0, d = 0, name = '';
            o.tblMain.find('>tbody>tr[data-id=' + id + ']').each(function () {
                var tds = $(this).find('td');
                c += parseFloat(tds.eq(5).text() || 0);
                d += parseFloat(tds.eq(6).text() || 0);
                name = name || tds.eq(0).text();
            });
            if (c != d) {
                //alert('此凭证不平衡');
                b.push(name);
                return;
            }
            a.push(id);
        });
        if (a.length && !b.length) {
            pgf.codeData('account.move.check', [user.id || 1, a.join(',')], function () {
                o.search();
                o.tblMain.find('.all-record-selector').removeAttr('checked');
            });
        }
        if (b.length) {
            alert('以下凭证不平衡：' + b.join(',') + '！');
        }
    }
    function uncheck() {
        var a = [], b = [];
        o.tblMain.find('input:checkbox:checked:not(.all-record-selector)').each(function () {
            var id = $(this).parent().attr('value');
            a.push(id);
        });
        if (a.length) {
            pgf.codeData('account.move.uncheck', [user.id || 1, a.join(',')], function () {
                o.search();
                o.tblMain.find('.all-record-selector').removeAttr('checked');
            });
        }
    }

    function print() {
        var doc = $(frames['printpz'].document).find('div');
        if (doc.find('table:hidden').size())
            doc.find('table:visible').remove();
        var table = doc.find('table').hide();
        o.tblMain.find('input:checkbox:checked:not(.all-record-selector)').each(function () {
            var t = table.clone().show(), trs = t.find('tr'),
                ymd = trs.eq(1).find('td'),
                md = ymd.find('span'),
                thisTds = $(this).parent().parent().find('td'),
                y = thisTds.eq(1).text(),
                m = y.split('/'), ctotal = 0, dtotal = 0, i = 4;
            ymd.prepend(m[0]);
            md.eq(0).append(m[1]);
            md.eq(1).append(m[2]);
            trs.eq(0).find('td:eq(3)').text(thisTds.eq(0).text());
            trs.eq(11).find('td:eq(5)').append(thisTds.eq(8).text());
            o.tblMain.find('tr[data-id=' + $(this).parent().attr('value') + ']').each(function () {
                var data = JSON.parse(decodeURI($(this).attr('data-head'))),
                    tds = trs.eq(i).find('td');
                if (data[14] || data[15]) {
                    ctotal += data[14];
                    dtotal += data[15];
                    tds.eq(0).text(data[12]);
                    if (data[17] == 2) {
                        tds.eq(1).text(data[18]);
                        tds.eq(2).text(data[13]);
                    }
                    else {
                        tds.eq(1).text(data[13]);
                    }
                    var debit = f.price(data[15], 2).split('.'),
                        credit = f.price(data[14], 2).split('.');
                    i++;
                    if (data[15]) {
                        for (var l = debit[0].length, j = l - 1; j >= 0; j--) {
                            tds.eq(12 - j).text(debit[0][l - j - 1]);
                        }
                        tds.eq(13).text(debit[1][0]);
                        tds.eq(14).text(debit[1][1]);
                    }
                    if (data[14]) {
                        for (var l = credit[0].length, j = l - 1; j >= 0; j--) {
                            tds.eq(24 - j).text(credit[0][l - j - 1]);
                        }
                        tds.eq(25).text(credit[1][0]);
                        tds.eq(26).text(credit[1][1]);
                    }
                }
            });
            var total = trs.eq(10).find('td');
            if (dtotal) {
                dtoatal = f.price(dtotal, 2).split('.');
                for (var l = dtoatal[0].length, j = l - 1; j >= 0; j--) {
                    total.eq(10 - j).text(dtoatal[0][l - j - 1]);
                }
                total.eq(11).text(dtoatal[1][0]);
                total.eq(12).text(dtoatal[1][1]);
            }
            if (ctotal) {
                ctotal = f.price(ctotal, 2).split('.');
                for (var l = ctotal[0].length, j = l - 1; j >= 0; j--) {
                    total.eq(22 - j).text(ctotal[0][l - j - 1]);
                }
                total.eq(23).text(ctotal[1][0]);
                total.eq(24).text(ctotal[1][1]);
            }
            doc.append(t);
        });
        frames['printpz'].print();
    }
    function pagerState(obj) {
        var p = $(obj).attr('data-pager-action');
        if (p == 'first') {
            o.search(0);
        }
        else if (p == 'next') {
            o.search(o.cpg + 1);
        }
        else if (p == 'previous') {
            o.search(o.cpg - 1);
        }
        else if (p == 'last') {
            o.search(Math.ceil(o.total / o.ps) - 1);
        }
    }
    function qmjz() {
        var a = [];
        a.push(o.id);
        a.push(user.id || 1);
        a.push(period.attr('date_start').split('-')[1]);
        a.push(o.journal_id);
        a.push(o.period_id);
        a.push(period.attr('date_stop'));
        a.push(1);
        a.push(o.credit);
        a.push(o.debit);
        pgf.codeData('account.move.qm.create', a, function (b) {
            o.search();
        })
    }
    function delQm() {
        pgf.codeData('account.move.qm.delete', [o.id], function () {
            o.search();
        });
    }
    o.ini = function () {
        if (!this.tbl) {
            var om = this;
            this.tbl = $('#tblSearch').find('.btnSearch').click(function () {
                om.search();
            }).end();
            this.tblMain = this.tbl.find('.oe-listview-content').find('.oe-record-edit-link').live('click', function () {
                om.tbl.hide();
                pzEdit.show(JSON.parse(decodeURI($(this).attr('data-head'))));
            }).end();
            this.tbl.find('.oe-list-add').click(function () {
                if (om.tbl.find('.oe-listview-content>tbody>tr[date-checked=0]').size() > 0) {
                    oeMessage.warn('存在未审核的凭证');
                }
                else {
                    qmjz();
                }
            });
            this.tbl.find('input:checkbox').live('click', function () {
                if ($(this).attr('checked')) {
                    $('.all-record-selector').attr('checked', 'checked');
                    om.tbl.find('button.btnChecked').enable();
                }
                else {
                    if (om.tblMain.find('tbody input:checkbox:checked:not(.all-record-selector)').size() == 0) {
                        $('.all-record-selector').removeAttr('checked');
                        om.tblMain.find('button.btnChecked').disable();
                    }
                }
            });
            this.tblMain.find('.all-record-selector').click(function () {
                if ($(this).attr('checked'))
                    om.tblMain.find('input:checkbox').attr('checked', 'checked');
                else
                    om.tblMain.find('input:checkbox').removeAttr('checked');
            });
            this.tbl.find('button.oe-list-check').click(function () {
                check();
            });
            this.tbl.find('button.oe-list-uncheck').click(function () {
                uncheck();
            });
            this.tblMain.find('button.oe-list-print').click(function () {
                print();
            });
            this.tbl.find('.filter_label').click(function () {
                //om.tbl.find('.filter_label').removeClass('enabled');
                if ($(this).hasClass('enabled')) {
                    $(this).removeClass('enabled');
                }
                else {
                    $(this).addClass('enabled');
                }
                o.search();
            });
            this.tbl.find('.oe-list-delete').click(function () {
                delQm();
            })
            period = om.tbl.find('#period_id_00');
            gAuto.period(period);
            o.readyPeriod(period);

            this.pager = this.tblMain.find('.oe-list-pager').find('button').click(function () {
                pagerState(this);
            }).end().find('span').click(function () {
                $(this).hide().next().show().val(o.ps);
            }).end().find('select').change(function () {
                o.ps = parseInt($(this).val());
                $(this).hide().prev().show();
                o.search();
            }).end();
        }
    }
    function btnEnable(cpg) {
        if (cpg < Math.ceil(o.total / o.ps) - 1) {
            o.pager.find('button').eq(2).enable();
            o.pager.find('button').eq(3).enable();
        }
        else {
            o.pager.find('button').eq(2).disable();
            o.pager.find('button').eq(3).disable();
        }
        if (cpg > 0) {
            o.pager.find('button').eq(0).enable();
            o.pager.find('button').eq(1).enable();
        }
        else {
            o.pager.find('button').eq(0).disable();
            o.pager.find('button').eq(1).disable();
        }
    }
    function beforeData(a) {
        var c = [], s = -1, r;
        if (a[0]) {
            o.journal_id = a[0][14];
        }
        o.pager.find('span c:eq(2),span c:eq(1)').text(a.length);
        var tDebit = 0, tCredit = 0;
        for (var i = 0, b; b = a[i]; i++) {
            b.push(i % 2 ? 'odd' : 'even');
            tDebit += b[8];
            tCredit += b[9];
            r = o.fdata(b, s);
            s = r.s;
            c.push(r.tr);
        }
        o.tblMain.find('tbody.ui-widget-content').html(c.join(''));
        o.tblMain.find('>tfoot>tr>td').eq(4).text(f.price(tDebit, 2)).end().eq(5).text(f.price(tCredit, 2));
        if (tCredit > tDebit) {
            o.credit = f.price(tCredit - tDebit, 2);
            o.debit = 0;
        }
        else {
            o.debit = f.price(tDebit - tCredit, 2);
            o.credit = 0;
        }
        o.searchEnd();
    }
    o.search = function (cpg) {
        var period_id = period.attr('_id'), btnActions = this.tbl.find('.oe-actions button');
        if (!period_id) return;
        o.period_id = period_id;
        pgf.codeData('account.move.qm.query', [period_id], function (a) {
            if (a && a[0]) {
                beforeData(a);
                o.id = a[0][15];
                btnActions.eq(0).disable();
                btnActions.eq(1).enable();
            }
            else {
                pgf.codeData('account.qm.jz.query', [period_id], function (a) {
                    beforeData(a);
                    btnActions.eq(0).enable();
                    btnActions.eq(1).disable();
                });
            }
        });
    }
    o.show = function () {
        this.search();
        this.tbl.show();
    }
    o.fdata = function (a, s) {
        var format = '<tr class="{15}" data-id="{0}" date-checked="{16}" data-head="{22}" style="color: black;">' +
                     '<td class="oe-field-cell" data-field="name">{1}</td><td class="oe-field-cell" data-field="date">{2}</td>' +
                     '<td class="oe-field-cell" data-field="period_id">{3}</td>' +
                     '<td class="oe-field-cell" data-field="account">{5} {6}</td><td class="oe-field-cell oe-number">{8}</td>' +
                     '<td class="oe-field-cell oe-number">{9}</td><td class="oe-field-cell" data-field="to_check">{10}</td>' +
                     '<td class="oe-field-cell" data-field="state" >{11}</td><td class="oe-field-cell">{12}</td></tr>';
        a.push(a[10]);
        a[10] = a[10] ? '全部审核完毕' : '存在未审核';
        if (s == a[1]) {
            a[1] = '';
            a[2] = '';
            a[3] = '';
            a[11] = '';
            a[12] = '';
        }
        else {
            s = a[1];
        }
        a[6] = a[13] == 1 ? a[6] : (a[7] + '_' + a[6]);
        //return format;
        return { tr: String.format.apply(null, [format].concat(a)), s: s };
    }
    return o;
})();


$(function () {
    pzSearch.ini();
})