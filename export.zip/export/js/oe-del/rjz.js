﻿/// <reference path="../jquery-1.7.2.js" />
/// <reference path="../common.js" />
/// <reference path="../common05.js" />
/// <reference path="../oeCommon.js" />


//var objMain = { tbl: null, pager: null, ps: 80,cpg:0, searchEnd: function () {
//    oeMessage.resize();
//}
//};

var oe = oe || window;

$(function () {
    rjz.ini();
})
oe.rjz = (function () {
    var o = $.extend(null, objMain, { tblMain: null }),
        content = '<tr class="{8}"><td class="oe-field-cell">{0}</td>' +
                  '<td class="oe-field-cell">{1}</td>' +
                  '<td class="oe-field-cell">{2}</td>' +
                  '<td class="oe-field-cell oe-number">{3}</td>' +
                  '<td class="oe-field-cell oe-number">{4}</td>' +
                  '<td class="oe-field-cell">{5}</td>' +
                  '<td class="oe-field-cell oe-number">{6}</td></tr>',
         zy = { '-': '借', '+': '贷', '30bn': '本年累计' },
         accountContent = '<tr id="{0}" code="{1}" name="{2}" class="{3}" partner="{5}" analytic="{6}"><td class="oe-field-cell"><c>{1} {2}<c></td></tr>',
    period = null, account = null, tblAccount = null, analytic_level = null, partner = null, analytic = null;

    function where(partner, analytic) {
        var a = [];
        if (partner) {
            a.push(' and aml.partner_id=' + partner);
        }
        if (analytic) {
            a.push(String.format(' and aml.move_id in ( select move_id from account_voucher where analytic_id={0} union all ' +
			   ' select move_id from account_invoice ai,account_invoice_line ail where ail.invoice_id=ai.id and ail.account_analytic_id={0} )', analytic));
            //a.push(' and aml.move_id in (select move_id from account_voucher where analytic_id=' + analytic + ')');
        }
        if (a.length) {
            return a.join(' ');
        }
        else
            return '';
    }
    function getFx(sum, b) {
        var s = '';
        if (sum) {
            s = zy[b[5]];
        }
        else {
            s = '平';
        }
        return s;
    }
    function search(code, name, partner, analytic) {
        var t = [], a = [], y = 0, fi = 0;
        $('.label>c').text(name);
        a.push(code);
        a.push(period.eq(0).attr('date_start'));
        a.push(period.eq(1).attr('date_stop'));
        //a.push(where(partner, analytic));
        a.push('');
        pgf.codeData('account.mxb.mx', a, function (a) {
            for (var i = 0, b = []; b = a[i]; i++) {
                var type = b[6];
                if (b[5] == '-') {
                    b[6] = b[3] - b[4];
                }
                else {
                    b[6] = b[4] - b[3];
                }
                y += b[6];
                if (type == 'qc') {
                    b[3] = '';
                    b[4] = '';
                    fi = y;
                }
                if (type == 'bq') {
                    b[5] = getFx(fi + b[6], b);
                    b[6] = f.price(fi + b[6], 2);
                }
                else if (type == 'bn') {
                    b[5] = getFx(b[6], b);
                    b[6] = f.price(b[6], 2);
                }
                else {
                    b[5] = getFx(y, b);
                    b[6] = f.price(y, 2);
                    b[1] = '<a href="#" data-id="' + b[7] + '">' + b[1] + '</a>';
                }
                t.push(formatStr(content, b));
            }
            o.tblMain.find('>tbody').html(t.join(''));
            o.searchEnd();
        });
    }
    function searchAccount() {
        var c = [], b = [], t = [];
        $('input[name=account_level]:checked').each(function () {
            c.push($(this).val());
        })
        if (!c.length) {
            c = [1, 2]
        }
        b[0] = (' and level in (' + c.join(',') + ')');
        b.push(account.eq(0).val() || 0);
        b.push(account.eq(1).val() || 9);
        //var partner = $('input[name=partner_id]');
        c = [1];

        b.push(c.join(','));
        var code = 'account.rjz.account';
        pgf.codeData(code, b, function (a) {
            for (var i = 0, b = []; b = a[i]; i++) {
                if (b[4] == 2 || b[4] == 3) {//c.length > 1 &&
                    b[3] = 'child-of-' + b[3];
                }
                t.push(formatStr(accountContent, b));
            }
            tblAccount.find('>tbody').html(t.join('')); //.end().treeTable({ treeColumn: 0 }); //.find('tbody tr:eq(0)').click();
        })
    }
    function get() {
        var type = jQuery.query.get('type'); //从哪个地方点进来的
        if (type == 'zz') {
            var code = jQuery.query.get('code');
            var l = JSON.parse(decodeURI(jQuery.query.get('level')));
            var p = JSON.parse(decodeURI(jQuery.query.get('period')));
            account.val(code);
            period.eq(0).val(p[2]).attr('date_start', p[0]);
            period.eq(1).val(p[3]).attr('date_stop', p[1]);
            if (l.length == 2 || l.indexOf('2') > 0 || !l.length) {
                $('input[name=account_level]:eq(1)').attr('checked', 'checked');
            }
            var p = jQuery.query.get('partner');
            if (p) {
                p = partner.split('_');
                partner.val(p[0]).attr('_id', p[1]);
                analytic_level.eq(0).attr('checked', 'checked');
            }
            var a = jQuery.query.get('analytic');
            if (a) {
                a = a.split('_');
                analytic.val(a[1]).attr('_id', a[0]);
                analytic_level.eq(1).attr('checked', 'checked');
            }
            searchAccount();
            return true;
        }
        return false;
    }
    function print() {
        $('#printer .line').html($('.tblMain')[0].outerHTML);
        $('#printer .head table tr:eq(0) th:eq(0)').text($('.tblMain').prev().text());
        window.print();
    }
    o.ini = function () {
        period = $('input[name=period_id]'), account = $('input[name=account_id]');
        period.each(function () { gAuto.period($(this)); });
        account.each(function () { gAuto.account($(this)); });
        analytic_level = [];
        this.tbl = $('#rjz');
        this.tblMain = this.tbl.find('.tblMain');
        partner = $('input[name=partner_id]');
        gAuto.co(partner, function () {
            if (partner.val()) {
                analytic_level.eq(0).attr('checked', 'checked');
            }
        });
        analytic = $('input[name=analytic_id]');
        gAuto.analytic(analytic, function () {
            if (analytic.val()) {
                analytic_level.eq(1).attr('checked', 'checked');
            }
        });
        tblAccount = $('.dvMain>.accountSelect table').find('>tbody>tr').live('click', function () {
            search($(this).attr('code'), $(this).attr('name'), $(this).attr('partner'), $(this).attr('analytic'));
        }).end();
        account.focus(function () {
            $(this).val($(this).attr('code'));
        }).blur(function () {
            $(this).val($(this).attr('title'));
        })
        $('.btnSearch').click(function () {
            //searchAccount();
        });
        $('.btnPrint').click(function () {
            print();
        });
        if (!get()) {
            o.readyPeriod(period);
        }
        this.tbl.find('.btnPay').click(function () {
            oe.pzEdit.show();
            o.tbl.hide();
        });
        this.tblMain.find('a').live('click', function () {
            pzEdit.show(null, $(this).attr('data-id'));
            o.tbl.hide();
        })
        searchAccount();
    };
    o.show = function () {
        o.tbl.show();
    }
    return o;
})()

oe.pzEdit = (function () {
    var o = $.extend(null, objMain, { tblMain: null }), emptyLine = ['', '', '', '', '', '', '', '', '', '', '', ''];
    var format = '<tr class="{8}" data_id="{0}"><th class="oe-record-edit-link">{9}</th><td>{1}</td><td>{2} {3}</td><td>{5}</td><td>{6}</td><td>{7}</td>' +
                    '<td class="oe-record-delete"><button type="button" style="visibility: hidden"></button></td></tr>',
    // btnAdd = '<img class="oe-record-edit-link-img" height="12" src="/web/static/src/img/pencil.gif" width="12">';
                   btnAdd = '<img class="oe-record-edit-link-img" height="12" src="/img/tbtn_new.gif" title="新增行" width="12">';


    fdataLine = function (a) {
        //return String.format.apply(null, [format].concat(a));
        var format = '<tr class="{8}" data_id="{0}" account_id="{9}" analytic_account="{10}"><th class="oe-record-edit-link" width="1">{11}</th><td class="oe_form_frame_cell oe_form_field_char formview_false_field_name_char_1 oe-field-cell">' +
                     '<input size="1" style="width: 100%;" name="name" type="text" class="field_char" value="{1}"></td><td class="oe_form_frame_cell oe_form_field_many2one" data-field="account_id">' +
                     '<table border="0" cellpadding="0" cellspacing="0" width="100%"><tbody><tr><td valign="top" width="100%"><input size="1" style="width: 100%" name="account_id" value="{2} {3}" code="{2}" title="{2} {3}" type="text" class="field_many2one">' +
                     '<span class="oe-m2o-drop-down-button"><img src="/web/static/src/img/down-arrow.png"></span></td><td><button class="oe_button oe_field_button oe-m2o-cm-button"><img src="/web/static/src/img/icons/STOCK_DIRECTORY_MENU.png">' +
                     '</button></td></tr></tbody></table></td><td class="oe_form_frame_cell oe_form_field_float oe-field-cell">' +
                     '<input size="1" style="width: 100%;" name="debit" type="text" value="{5}" class="field_float oe-number debite"></td><td class="oe_form_frame_cell oe_form_field_float oe-field-cell">' +
                     '<input size="1" style="width: 100%;" name="credit" type="text" value="{6}" class="field_float oe-number credit"></td><td class="oe-record-delete" width="1"><button name="delete" type="button"></button></td></tr>';
        //<td class="oe_form_frame_cell oe_form_field_many2one oe-field-cell">' +
        //'<table border="0" cellpadding="0" cellspacing="0" width="100%"><tbody><tr><td valign="top" width="100%"><input size="1" style="width: 100%" value="{7}" name="analytic_account_id" type="text" class="field_many2one">' +
        //'<span class="oe-m2o-drop-down-button"><img src="/web/static/src/img/down-arrow.png"></span></td><td><button class="oe_button oe_field_button oe-m2o-cm-button">' +
        //'<img src="/web/static/src/img/icons/STOCK_DIRECTORY_MENU.png"></button></td></tr></tbody></table></td>
        for (var i = 0; i < a.length; i++) {
            a[i] = a[i] || '';
        }
        a[11] = a[11] || btnAdd;
        return String.format.apply(null, [format].concat(a));
    }
    addLine = function (obj) {
        var i = null;
        if (obj) {
            i = $(fdataLine(emptyLine)).insertBefore(o.tbl.find('.tblLine>tbody>tr').has(obj));
        }
        else {
            i = $(fdataLine(emptyLine)).appendTo(o.tbl.find('.tblLine > tbody'));
        }
        autoAccount(i.find('input[name=account_id]'));
        lineResort();
        return i;
    }
    autoAccount = function (obj) {
        gAuto.account($(obj), function (data, target) {
            var i = o.tbl.find('.tblLine > tbody > tr:visible').has(target);
            i.attr('account_id', data.id);
            //i.children().has(obj).next().find('input').focus();
        });
    }
    lineResort = function () {//重新给tr添加元素
        o.tbl.find('.tblLine > tbody > tr:visible').each(function (i) {
            $(this).removeClass().addClass(i % 2 ? 'odd' : 'even');
        });
    }
    total = function (obj) { //计算借代双方的合计
        var c = 0, d = 0;
        o.tbl.find('.tblLine > tbody >tr').each(function () {
            if (obj && $(this).has(obj).size()) {
                null;
            }
            else {
                $(this).find('input[name=credit]').each(function () {
                    c += parseFloat($(this).val()) || 0;
                });
                $(this).find('input[name=debit]').each(function () {
                    d += parseFloat($(this).val()) || 0;
                });
            }
        });

        o.tbl.find('.tblLine>tfoot>tr>td.credit').text(c);
        o.tbl.find('.tblLine>tfoot>tr>td.debit').text(d);
        o.tbl.find('.tblLine>tfoot>tr>td.chineseNumber').text(c == d ? DX(c) : '');
        return c - d;
    };
    save = function (obj) {//保存
        var n = o.tblHead.find('input'), a = [], update = [], c = [], insert = [], del = [];
        //a.push(n.eq(0).val());
        a.push(o.id || 0);
        a.push(user.id || 1);
        a.push(n.eq(3).val()); //name
        a.push(n.eq(3).attr('j_id'));
        a.push(n.eq(6).attr('_id')); //period
        a.push(n.eq(5).val()); //date
        a.push(n.eq(7).val()); //proof
        a.push(n.eq(1).attr('_id') || -1);
        //        if (o.tbl.find('.tblLine>tfoot>tr>td.credit').text() != o.tbl.find('.tblLine>tfoot>tr>td.debit').text()) {
        //            oeMessage.warn('借贷双方不平衡');
        //            return;
        //        }
        o.tbl.find('.tblLine >tbody >tr:visible').each(function () {
            c = [];
            c.push($(this).attr('data_id'));
            c.push(user.id || 1);
            c.push($(this).attr('account_id'));
            c.push(a[3]); //journal_id
            c.push($(this).attr('analytic_account'));
            c.push(a[4]);
            c.push(''); //move_id 6
            $(this).find('input').each(function () {
                c.push($(this).val());
            })
            c[4] = c[4] || 'null';
            c[9] = c[9] || 0;
            c[10] = c[10] || 0;
            if (c[7] && c[8] && (c[9] || c[10]))//6account 9analytic
            {
                if (c[2]) {
                    var d = c.slice(0);
                    d[9] = c[10];
                    d[10] = c[9];
                    insert.push(d);
                    //d[0] ? update.push(d) : insert.push(d);
                }
                c[2] = n.eq(1).attr('_id');
                insert.push(c);
                //c[0] ? update.push(c) : insert.push(c);
            }
        })
        if (insert.length + update.length > 0) {
            $(obj).text('正在保存...').disable();
            pgf.codeData('account.move.rjz.insert', a, function (b) {
                var j = 0;
                o.id = b[0];
                if (update.length) {
                    for (var i = 0; i < update.length; i++) {
                        update[i][6] = b[0];
                    }
                    j++;
                    pgf.batchUpdate('pzUpdateLine', update, function () {
                        j--;
                        if (j == 0) {
                            $(obj).text('保存').enable();
                        }
                    });
                }
                if (insert.length) {
                    for (var i = 0; i < insert.length; i++) {
                        insert[i][6] = b[0];
                    }
                    j++;
                    pgf.batchUpdate('pzInsertLine', insert, function () {
                        j--;
                        if (j == 0) {
                            $(obj).text('保存').enable();
                        }
                    });
                }
            });
        }
        else {
            oeMessage.show('有效明细不足！');
        }
    }
    o.ini = function () {
        if (!this.tbl) {
            var om = this;
            this.tbl = $('#tblEdit').find('.oe_vm_switch_list').click(function () {//查看列表
                rjz.show();
                om.tbl.hide();
            }).end().find('.oe_form_button_save').click(function () {
                save(this);
            }).end();
            this.tblHead = this.tbl.find('.tblHead');
            var name = this.tblHead.find('input[name=name]');
            gAuto.accountR(this.tblHead.find('input[name=account]'), function (c) {
                name.attr('j_id', c.journal_id);
            }); //选择科目
            gAuto.pzNameR(name); //凭证号
            gAuto.periodM(this.tblHead.find('input[name=period_id]'), function (c) {//会计期
                name.val(c.move_name).attr('_id', c.sequence_id);
            });
            //this.tblLine = this.tbl.find('.tblLine');
            this.tbl.find('.tblLine input[name=name]').live('blur', function () {
                o.lineName = $(this).val().trim();
            }).live('focus', function () {
                $(this).val($(this).val().trim() || o.lineName);
            });
            this.tbl.find('.tblLine input[name=account_id]').live('blur', function () {
                $(this).val($(this).attr('title'));
            }).live('focus', function () {
                $(this).val($(this).attr('code'));
            });
            this.tbl.find('.tblLine button.oe-list-add').click(function () {//添加行
                addLine();
            });
            this.tbl.find('.tblLine th.oe-record-edit-link').live('click', function () {
                addLine(this);
            })
            this.tbl.find('.tblLine button[name=delete]').live('click', function () {//删除行
                var n = om.tbl.find('.tblLine > tbody > tr').has(this)
                if (n.attr('data_id'))
                    n.hide();
                else
                    n.remove();
                lineResort();
            });
            this.tbl.find('.tblLine input[name=debit]').live('blur', function () {
                if ($.isNumeric($(this).val()) || !$(this).val()) {
                    $(this).val(parseFloat($(this).val()) || '');
                    total();
                }
                else {
                    $(this).val('').focus();
                }
            }).live('focus', function () {
                var n = om.tbl.find('.tblLine >tbody > tr').has(this), i;
                if (n.find('input[name=credit]').val() > 0) {
                    n = n.find('input');
                    i = jQuery.inArray(this, n);
                    n.eq(i + 1).focus();
                    return false;
                }
            });
            this.tbl.find('.tblLine input[name=credit]').live('blur', function () {
                if ($.isNumeric($(this).val()) || !$(this).val()) {
                    $(this).val(parseFloat($(this).val()) || '');
                    total();
                }
                else {
                    $(this).val('').focus();
                }
            }).live('focus', function () {
                var n = om.tbl.find('.tblLine >tbody > tr').has(this), i;
                if (n.find('input[name=debit]').val() > 0) {
                    n = n.find('input');
                    i = jQuery.inArray(this, n);
                    n.eq(i + 1).focus();
                    return false;
                }
            });
            this.tbl.find('.tblLine input').live('keydown', function (evt) {
                o.lineName = $(this).attr('name') == 'name' ? $(this).val() : o.lineName;
                var keyCode = evt.keyCode, n;
                if (keyCode == 13)//enter
                {
                    n = om.tbl.find('.tblLine > tbody > tr').has(this).next();
                    if (!n.size())
                        n = addLine();
                    n.find('input[name=' + evt.target.name + ']').focus();
                }
                if (keyCode == 9) {
                    n = om.tbl.find('.tblLine > tbody > tr').has(this).find('input');
                    // n = om.tbl.find('.tblLine > tbody > tr').has(this).find('input').has(this).next();
                    var i = jQuery.inArray(this, n);
                    n.eq(i + 1).focus();
                    if (!n.eq(i + 1).size()) {
                        n = om.tbl.find('.tblLine > tbody > tr').has(this).next();
                        if (!n.size()) {
                            n = addLine();
                        };
                        n.find('input:eq(0)').focus();
                    }
                    return false;
                };
                if (keyCode == 187 && (evt.target.name == 'debit' || evt.target.name == 'credit')) {//输入等号
                    var n = total(this);
                    if (n > 0) {
                        om.tbl.find('.tblLine > tbody > tr').has(this).find('input[name=debit]').val(Math.abs(n)).focus();
                    }
                    else if (n < 0)
                        om.tbl.find('.tblLine > tbody > tr').has(this).find('input[name=credit]').val(Math.abs(n)).focus();
                    return false;
                }
            });

            this.tbl.find('.oe_form_button_copy').click(function () {
                om.tbl.find('input,button:not(.oe_vm_switch button)').enable();
                pgf.codeData('pzCode', [], function (a) {
                    o.tblHead.find('input:eq(1)').val(a[0][0]);
                })
                o.id = null;
            });

            this.tbl.find('.oe_form_button_add').click(function () {
                o.show();
            })
        }
    }
    o.show = function (a, id) {
        this.ini();
        var om = this, checked;
        o.id = id;
        if (id) {
            a = [];
            pgf.codeData('account.rjz.detail', [id], function (b) {
                var d = b[0].slice(0, 3), l = b.length;

                for (var i = 0, c; c = b[i]; i++) {
                    c = c.slice(15);
                    c[3] = c[8] == 1 ? (c[4] + '_' + c[3]) : c[3];
                    if (i == 0) d[0] = d[0] + ' ' + c[3];
                    if (c[9] == d[1]) {
                        if (l > 1)
                            continue;
                        else {
                            c[2] = c[3] = c[9] = '';
                        }
                    }
                    else {
                        var e = c[5];
                        c[5] = c[6];
                        c[6] = e;
                    }
                    a.push(fdataLine(c));
                }
                fdataHead(b[0].slice(2, 15), d);
                if (b[0][3]) {
                    om.tbl.find('input,button:not(.oe_vm_switch button)').disable();
                }
                else {
                    om.tbl.find('input,button:not(.oe_vm_switch button)').enable();
                }
                b = emptyLine;
                for (; 8 - i > 0; i++) {
                    a.push(fdataLine(b));
                }
                var o = om.tbl.find('.tblLine > tbody').html(a.join(''));
                o.find('input[name=account_id]').each(function () {
                    autoAccount(this);
                });
                total();
            });
            om.tbl.show();
        }
        else {
            noData();
        }
    }
    function noData() { //新增时无数据
        pgf.codeData('account.move.rjz.new', [], function (a) {
            var b = [];
            a = a[0];
            o.tbl.find('input,button:not(.oe_vm_switch button)').enable();
            b.push(a[8] + ' ' + a[7]);
            b.push(a[6]);
            b.push(a[4]);
            fdataHead(['', '', a[0], a[1], a[3], , '', '', '1', user.name || user.login, a[2], a[4], a[5]], b);
            var a = [], b = ['', '', '', '', '', '', '', '', '', '', '', '', ''];
            for (var i = 0; 8 - i > 0; i++) {
                a.push(fdataLine(b));
            }
            var tbd = o.tbl.find('.tblLine > tbody').html(a.join(''));
            tbd.find('input[name=account_id]').each(function () {
                autoAccount(this);
            });
            total();
            o.tbl.show();
        })
    }
    fdataHead = function (a, b) {
        var n = o.tblHead.find('input'); //.each(function (i) {
        //    $(this).val(a[i]);
        //})
        if (b) {
            n.eq(1).val(b[0]).attr('_id', b[1]); //account
            o.journal_id = b[2];
            n.eq(3).attr('j_id', b[2]);
        }
        //n.eq(1).val(a[0]).attr('journal_id', a[11]);
        n.eq(2).val(a[1]).attr('_id', a[12]);
        n.eq(3).val(a[2]).attr('_id', a[12]).attr('p_id',a[10]); //name
        n.eq(5).val(a[3]); //date
        n.eq(6).val(a[4]).attr('_id', a[10]); //period
        n.eq(7).val(a[8]); //proof
        n.eq(8).val(a[9]).attr('_id', a[7])//creator;
    }
    return o;
})()
