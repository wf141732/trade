﻿/// <reference path="../jquery-1.7.2.js" />
/// <reference path="../common.js" />
/// <reference path="../common05.js" />
/// <reference path="../oeCommon.js" />

var oe = oe || window;
$(function () {
    syb.ini();
})

oe.syb = (function () {
    var o = $.extend(null, objMain, { tblMain: null }), //<td class="oe-field-cell oe-number">{6}</td>
        content = '<tr><td class="oe-field-cell {7}">{1}</td>' +
                '<td class="oe-field-cell">{2}</td>' +
                '<td class="oe-field-cell oe-number">{3}</td>' +
                '<td class="oe-field-cell oe-number">{5}</td>' +
                '</tr>';
    o.ini = function () {
        this.tblMain = $('.tblMain');
        var om = this, period = $('input[name=period_id]'), a = [];
        gAuto.period(period);
        o.readyPeriod(period);
        //        pgf.codeData('account.period.now', [period.attr('date_stop')], function (a) {
        //            a = a[0];
        //            period.attr('_id', a[0]);
        //            period.val(a[1]);
        //            period.attr('date_start', a[2]);
        //            period.attr('date_stop', a[3]);
        //        });
        this.btnSearch = $('.btnSearch').click(function () {
            a = [];
            a.push(period.attr('_id'));
            a.push(period.attr('date_start'));
            a.push(period.attr('date_stop'));
            pgf.codeData('syb', a, function (a) {
                var c = [], type = '', sy3 = 0, sy5 = 0, sy6 = 0;
                for (var i = 0, b = []; b = a[i]; i++) {
                    if (b[7]) {//如果为二级
                        if (b[4] == 'add') {
                            sy3 = sy3 + b[3] || 0;
                            sy5 = sy5 + b[5] || 0;
                            sy6 = sy6 + b[6] || 0;
                        }
                        else {
                            sy3 = sy3 - b[3] || 0;
                            sy5 = sy5 - b[5] || 0;
                            sy6 = sy6 - b[6] || 0;
                        }
                    }
                    else {
                        sy3 = sy3 + b[3] || 0;
                        sy5 = sy5 + b[5] || 0;
                        sy6 = sy6 + b[6] || 0;
                        b[3] = sy3;
                        b[5] = sy5;
                        b[6] = sy6;
                    }
                    b[7] = b[7] ? 'level2' : '';
                    if (b[4] && b[7] && b[4] != type) {
                        b[7] = 'level1';
                        b[1] = (b[4] == 'add' ? '加：' : '减：') + b[1];
                        type = b[4];
                    }
                    if (!b[4]) {
                        type = '';
                    }
                    c.push(String.format.apply(null, [content].concat(b)));
                }
                om.tblMain.find('>tbody').html(c.join(''));
                om.endSearch();
            });
        })
    }
    return o;
})()