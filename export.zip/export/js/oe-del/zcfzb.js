﻿/// <reference path="../jquery-1.7.2.js" />
/// <reference path="../common.js" />
/// <reference path="../common05.js" />
/// <reference path="../oeCommon.js" />

var oe = oe || window;
$(function () {
    zcfzb.ini();
})

oe.zcfzb = (function () {
    var o = $.extend(null, objMain, { tblMain: null }),
        head = '<th class="oe-sortable" data-id="name">{1}</th>' +
               '<th class="oe-sortable" data-id="line_number">行次</th>' +
               '<th class="oe-sortable" data-id="qm">期末数</th>' +
               '<th class="oe-sortable" data-id="qc">年初数</th>',
        content = '<td class="oe-field-cell {5}" data-field="name">{1}</td>' +
                  '<td class="oe-field-cell" data-field="line_number">{2}</td>' +
                  '<td class="oe-field-cell oe-number" data-field="qm">{3}</td>' +
                  '<td class="oe-field-cell oe-number" data-field="qc">{4}</td>',
         empty = ['', '', '', '', '', '', '', ''],
         foot = '<td class="oe-list-footer">{1}</td>' +
              '<td class="oe-list-footer">{2}</td>' +
              '<td class="oe-list-footer oe-number">{3}</td>' +
              '<td class="oe-list-footer oe-number">{4}</td>',
          periodData = [];

    function fdata(a) {
        var title = [], h = '', zc = [], fz = [], zcl = 0, fzl = 0, trs = [];
        for (var i = 0, b = []; b = a[i]; i++) {
            if (!b[5]) {
                title.push(b);
                zcl ? fzl++ : zcl++;
            }
            fzl ? fz.push(b) : zc.push(b);
            fzl ? fzl++ : zcl++;
        }
        var th = o.tbl.find('>thead>tr>th');
        for (var i = 0, b = []; b = title[i]; i++) {//头上的文字
            th.eq(i * 4).text(b[1]);
        }
        for (var i = 0, b = []; b = zc[i]; i++) {//合计的类别
            if (b[7]) {
                for (var j = 0, c = []; c = zc[j]; j++) {
                    if (c[6] > b[8] && c[6] < b[6] && !c[7]) { //b[8] parent order                                
                        b[3] = (b[3] || 0) + parseFloat(c[3] || 0) + parseFloat(c[4] || 0);
                        b[4] = (b[4] || 0) + parseFloat(c[4] || 0);
                    }
                }
                b[3] = f.price(b[3], 2);
                b[4] = f.price(b[4], 2);
                zc[i] = b;
            }
        }
        for (var i = 0, b = []; b = fz[i]; i++) {//合计的类别
            if (b[7]) {
                for (var j = 0, c = []; c = fz[j]; j++) {
                    if (c[6] > b[8] && c[6] < b[6] && !c[7]) { //b[8] parent order
                        b[3] = (b[3] || 0) + parseFloat(c[3] || 0);
                        b[4] = (b[4] || 0) + parseFloat(c[4] || 0);
                    }
                }
                b[3] = f.price(b[3], 2);
                b[4] = f.price(b[4], 2);
                fz[i] = b;
            }
        }
        //尾部
        o.tbl.find('>tfoot>tr').html(String.format.apply(null, [foot].concat(zc[zc.length - 1])) +
                                String.format.apply(null, [foot].concat(fz[fz.length - 1])));
        zc.splice(zc.length - 1);
        fz.splice(fz.length - 1);
        zcl--;
        fzl--;
        for (var i = 1, l = zcl > fzl ? zcl : fzl; i < l; i++) {
            if (zc[i])
                zc[i][5] = 'level' + (zc[i][5] - 1);
            if (fz[i])
                fz[i][5] = 'level' + (fz[i][5] - 1);
            //&& zc[i][3]
            if (zc[i] && (zc[i][3] || zc[i][4]) && (isNumber(zc[i][3]) || !zc[i][3]) && !zc[i][7]) {
                zc[i][3] = f.price((zc[i][3] || 0) + (zc[i][4] || 0), 2);
                zc[i][3] = '<a href="zz.htm?type=zcfzb&typeid=' + zc[i][0] + '&period=' + encodeURI(JSON.stringify(periodData)) + '">' + zc[i][3] + '</a>';
            } //&& fz[i][3] 
            if (fz[i] && (fz[i][3] || fz[i][4]) && (isNumber(fz[i][3]) || fz[i][3]) && !fz[i][7]) {
                fz[i][3] = f.price((fz[i][3] || 0) + (fz[i][4] || 0), 2);
                fz[i][3] = '<a href="zz.htm?type=zcfzb&typeid=' + fz[i][0] + '&period=' + encodeURI(JSON.stringify(periodData)) + '">' + fz[i][3] + '</a>';
            }
            if (zc[i] && zc[i][4] != "") {
                zc[i][4] = f.price(zc[i][4], 2);
            }
            //            if (zc[i] && zc[i][3] != "") {
            //                zc[i][3] = f.price(zc[i][3], 2);
            //            }
            if (fz[i] && fz[i][4] != "") {
                fz[i][4] = f.price(fz[i][4], 2);
            }
            //            if (fz[i] && fz[i][3] != "") {
            //                fz[i][3] = f.price(fz[i][3], 2);
            //            }
            trs.push('<tr class=' + (i % 2 ? 'odd' : 'even') + '>' +
                                String.format.apply(null, [content].concat(zc[i] ? zc[i] : empty)) +
                                String.format.apply(null, [content].concat(fz[i] ? fz[i] : empty)) + '</tr>');
        }
        o.tbl.find('>tbody').html(trs.join(''));
        o.searchEnd();
    }
    o.ini = function () {
        this.tbl = $('.tblMain');
        var period = $('input[name=period_id]');
        $('.btnPrint').click(function () {
            $('#printer .line').html($('.tblMain')[0].outerHTML);
            window.print();
        });
        this.btnSearch = $('.btnSearch').click(function () {
            if (!period.attr('date_stop')) {
                return;
            }
            pgf.codeData('zcfzb', [period.attr('date_stop')], function (a) {
                periodData.push(period.attr('_id'));
                periodData.push(period.val());
                periodData.push(period.attr('date_start'));
                periodData.push(period.attr('date_stop'));
                fdata(a);
            })
        });
        o.readyPeriod(period);
        //        pgf.codeData('account.period.now', [period.attr('date_stop')], function (a) {
        //            a = a[0];
        //            period.val(a[1]);
        //            period.attr('date_start', a[2]);
        //            period.attr('date_stop', a[3]);
        //        });
        var d = new Date();
        var date = d.getFullYear() + '年' + (d.getMonth() + 1) + '月' + d.getDate() + '日';
        $('.head table tr:eq(1) td:eq(1)').html(date);
        gAuto.period(period);
    }
    return o;
})()

