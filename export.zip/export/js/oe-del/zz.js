﻿/// <reference path="../jquery-1.7.2.js" />
/// <reference path="../common.js" />
/// <reference path="../common05.js" />
/// <reference path="../oeCommon.js" />
/// <reference path="../jqueryplugin/Jquery.Query.js" />


var oe = oe || window;

$(function () {
    zz.ini();
})
oe.zz = (function () {
    var o = $.extend(null, objMain, { tblMain: null }),
        content = '<tr class="{8}"><td class="oe-field-cell"><a href="mxz.htm?type=zz&code={0}&level={9}&period={10}{11}{12}">{0}</a></td>' +
                  '<td class="oe-field-cell">{1}</td>' +
                  '<td class="oe-field-cell">{2}</td>' +
                  '<td class="oe-field-cell">{3}</td>' +
                  '<td class="oe-field-cell oe-number">{4}</td>' +
                  '<td class="oe-field-cell oe-number">{5}</td>' +
                  '<td class="oe-field-cell oe-number">{6}</td>' +
                  '<td class="oe-field-cell oe-number">{7}</td></tr>',
         zy = { '10qc': '本期期初', '20bq': '本期合计', '30bn': '本年累计' },
         period = null, account = null, analytic_level = null;

    function displayBal(bqqc, bnqc, a) {
        if (a[3] == '10qc') {
            bqqc = a[7];
            bnqc = a[7];
        }
        else if (a[3] == '20bq') {
            a[7] = a[7] + bqqc;
            bqqc = a[7];
        }
        else if (a[3] == '30bn') {
            //this[7] = this[7] + bnqc;
            null;
            //bnqc = this[6];
        }
        return { bnqc: bnqc, bqqc: bqqc, bal: a[7] };
    }
    function compute(a, b, c) { //数据处理
        var tr = [], st = '', i = 0, stp = '', bqqc = 0, bnqc = 0;
        //$(a).each(function () {
        for (var i = 0, b = []; b = a[i]; i++) {
            if (b[1] != st) {
                st = b[1];
                if (b[3] != '10qc') {
                    var empty = [b[0], b[1], b[2], zy['10qc'], '', '', '', ''];
                    empty.push(i % 2 ? 'odd' : 'even');
                    tr.push(formatStr(content, empty));
                    i++;
                    b[0] = '';
                    b[1] = '';
                    bqqc = 0;
                    bnqc = 0;
                }
            }
            else {
                st = b[1];
                b[0] = '';
                b[1] = '';
            }
            //存在partner_id
            b[11] = b[7] ? ('&partner=' + b[7] + '_' + b[8]) : '';
            b[12] = b[7] ? ('&analytic=' + b[9] + '_' + b[10]) : '';
            b[8] = (i % 2 ? 'odd' : 'even');
            b[4] = f.price(b[4], 2);
            b[5] = f.price(b[5], 2);
            if (b[6] == '-') {
                b[7] = (b[4] || 0) - (b[5] || 0);
                var o = displayBal(bqqc, bnqc, b);
                b[7] = o.bal;
                bqqc = o.bqqc;
                bnqc = o.bnqc;
                b[6] = b[7] ? '借' : '平';
            }
            else {
                b[7] = (b[5] || 0) - (b[4] || 0);
                var o = displayBal(bqqc, bnqc, b);
                b[7] = o.bal;
                bqqc = o.bqqc;
                bnqc = o.bnqc;
                b[6] = b[7] ? '贷' : '平';
            }

            b[7] = b[7] ? f.price(b[7], 2) : '';
            if ((!b[4] && !b[5]) || b[3] == '10qc') {
                b[4] = '';
                b[5] = '';
                //b[7] = '';
            }
            b[3] = zy[b[3]];
            b[9] = encodeURI(JSON.stringify(b));
            b[10] = encodeURI(JSON.stringify(c.slice(0,4)));
            tr.push(formatStr(content, b));
        };
        for (; i < 5; i++) {
            tr.push(formatStr(content, ['','','','','','','','','','']));
        }
        $('.tblMain>tbody').html(tr.join(''));
        zz.searchEnd();
    }
    function search(typeid) {
        var b = [], c = [];
        b.push(period.eq(0).attr('date_start'));
        b.push(period.eq(1).attr('date_stop'));
        b.push(account.eq(0).attr('code') || '0');
        b.push(account.eq(1).attr('code') || '9');
        $('input[name=account_level]:checked').each(function () {
            c.push($(this).val());
        })
        if (c.length) {
            b.push(' and a.level in (' + c.join(',') + ')');
        }
        else {
            b.push('');
        }
        if (typeid) {
            b.push(' and a.id in (select a.myid from account_zcfzb_type_rel r,(select id,id as myid from account_account where level=1 union all select parent_id,id from account_account where level=2) as a ' +
               ' where a.id=r.account_id and r.type_id=' + typeid + ')');
        }
        else {
            b.push('');
        }
        if (analytic_level.eq(0).attr('checked')) {
            b.push(',s.rname,s.partner_id');
            b.push("||' '||COALESCE(s.rname,'')");
        }
        else {
            b.push(''); b.push('');
        }
        if (analytic_level.eq(1).attr('checked')) {
            b.push(',s.analytic_id,aaa.name');
            b.push("||' '||COALESCE(aaa.name,'')");
        }
        else {
            b.push(''); b.push('');
        }
        pgf.codeData('account.zz.partner', b, function (a) {
            b[2] = period.eq(0).val();
            b[3] = period.eq(1).val();
            compute(a, c, b);
        });
    };
    function print() {
        $('#printer .line').html($('.tblMain')[0].outerHTML);
        window.print();
    }
    o.ini = function () {
        period = $('input[name=period_id]'), account = $('input[name=account_id]');
        period.each(function () { gAuto.period($(this)); });
        account.each(function () { gAuto.accountQ($(this)); });
        analytic_level = $('input[name=analytic_level]');
        var partner = $('input[name=partner_id]');
        gAuto.co(partner, function () {
            if (partner.val()) {
                analytic_level.eq(0).attr('checked', 'checked');
            }
        });
        var analytic = $('input[name=analytic_id]');
        gAuto.analytic(analytic, function () {
            if (analytic.val()) {
                analytic_level.eq(1).attr('checked', 'checked');
            }
        });

        account.focus(function () {
            $(this).val($(this).attr('code'));
        }).blur(function () {
            $(this).val($(this).attr('title'));
        })
        $('.btnSearch').click(function () {
            search();
        });
        $('.btnPrint').click(function () {
            print();
        });
        var type = jQuery.query.get('type'); //从哪个地方点进来的
        if (type == 'zcfzb') {
            var a = JSON.parse(decodeURI($.query.get('period')));
            period.val(a[1]);
            period.attr('date_start', a[2]);
            period.attr('date_stop', a[3]);
            //account.val($.query.get('code'));
            search($.query.get('typeid'));
        }
        else {
            o.readyPeriod(period);
            //            pgf.codeData('account.period.now', [], function (a) {
            //                a = a[0];
            //                period.val(a[1]);
            //                period.attr('date_start', a[2]);
            //                period.attr('date_stop', a[3]);
            //            });
        }
    }
    return o;
})()