﻿/// <reference path="jquery-1.7.1.js" />
/// <reference path="jquery-ui-1.8.10/js/jquery-ui-1.8.10.custom.min.js" />

var objMain = { tbl: null, pager: null, ps: 80, cpg: 0,
    searchEnd: function () {
        oeMessage.resize();
    },
    readyPeriod: function (period) {
        pgf.codeData('account.period.now', [], function (a) {
            if (a[0]) {
                a = a[0];
                period.attr('_id', a[0]);
                period.val(a[1]);
                period.attr('date_start', a[2]);
                period.attr('date_stop', a[3]);
            }
            else {
                oeMessage.warn('未建立本月会计期！');
            }
        });
    }
};

$(function () {
    pm.ini();
    ur.ini();
    if (pm.enable) {
        gtips.showAjax = function () {
            oeMessage.show();
        }
        gtips.hideAjax = function () {
            oeMessage.hide();
        };
    }
})

var user = (function () {
    var o = {id:null,name:null,login:null} ;    
    return o;
})()

var oeMessage = (function () {
    var o = {};
    o.show = function () {
        pm.postMsg({ code: 'loadingNoB', message: '正在加载...' });
    }
    o.showBlock = function () {
        pm.postMsg({ code: 'startLoading', message: '正在加载...' });
    }
    o.hide = function () {
        pm.postMsg({ code: 'endLoading' });
    }
    o.resize = function () {
        pm.postMsg({ code: 'resize', height: document.height });
    }
    o.warn = function (msg) {
        alert(msg);
    }
    return o;
})()

var gAuto = {
    co: function (txts, callback) {// 智能提示公司
        this.complete(txts, 1, 15, 0, function (a) {//ID,助记名,全称,拼音码,平台ID
            var c = {}
            c.label = a[1];
            c.value = a[1];
            c.id = a[0];
            c.tips = a[1]; // 额外提示信息
            c.ptid = a[1];
            return c;
        }, callback, 1, 'a-partner');
    },
    pzName: function (txts, callback) {// 智能提示公司
        this.complete(txts, 1, 15, 0, function (a) {//ID,助记名,全称,拼音码,平台ID
            var c = {}
            c.label = a[1];
            c.value = a[1];
            c.id = a[0];
            c.tips = a[1]; // 额外提示信息
            c.ptid = a[1];
            return c;
        }, callback, 1, 'a-account.move.name');
    },
    pzNameP: function (txts, callback) {// 智能提示凭证，根据会计期
        this.complete(txts, 1, 15, 0, function (a) {//ID,助记名,全称,拼音码,平台ID
            var c = {}
            c.label = a[1];
            c.value = a[1];
            c.id = a[0];
            c.tips = a[1]; // 额外提示信息
            c.ptid = a[1];
            return c;
        }, callback, 1, 'a-account.move.name.period');
    },
    pzNameR: function (txts, callback) {// 只能提示日记账的凭证号
        this.complete(txts, 1, 15, 0, function (a) {//ID,助记名,全称,拼音码,平台ID
            var c = {}
            c.label = a[1];
            c.value = a[1];
            c.id = a[0];
            c.tips = a[1]; // 额外提示信息
            c.ptid = a[1];
            return c;
        }, callback, 1, 'a-account.move.name.rjz');
    },
    analytic: function (txts, callback) {// 智能提示公司
        this.complete(txts, 1, 15, 0, function (a) {//ID,助记名,全称,拼音码,平台ID
            var c = {}
            c.label = a[1];
            c.value = a[1];
            c.id = a[0];
            c.tips = a[1]; // 额外提示信息
            c.ptid = a[1];
            return c;
        }, callback, 1, 'a-account.analytic');
    },
    account: function (txts, callback) {// 智能提示科目
        this.complete(txts, 1, 15, 0, function (a) {//ID,助记名,全称,拼音码,平台ID
            var c = {}, d = a[1] + ' ' + (a[4] == 1 ? (a[3] + '_' + a[2]) : a[2]);

            c.label = d;
            c.value = d;
            c.id = a[0];
            c.tips = d; // 额外提示信息
            c.ptid = a[1];
            return c;
        }, callback, 1, 'a-account');
    },
    accountR: function (txts, callback) {// 智能提示日记账科目
        this.complete(txts, 1, 15, 0, function (a) {//ID,助记名,全称,拼音码,平台ID
            var c = {}, d = a[1] + ' ' + (a[4] == 1 ? (a[3] + '_' + a[2]) : a[2]);

            c.label = d;
            c.value = d;
            c.id = a[0];
            c.tips = d; // 额外提示信息
            c.ptid = a[1];
            c.journal_id = a[5];
            return c;
        }, callback, 1, 'a-account.rjz');
    }, 
    accountQ: function (txts, callback) {// 智能提示查询科目
        this.complete(txts, 1, 15, 0, function (a) {//ID,助记名,全称,拼音码,平台ID
            var c = {}, d = a[1] + ' ' + (a[4] == 1 ? (a[3] + '_' + a[2]) : a[2]);

            c.label = d;
            c.value = d;
            c.id = a[0];
            c.tips = d; // 额外提示信息
            c.ptid = a[1];
            c.journal_id = a[5];
            return c;
        }, callback, 1, 'a-account.query');
    },
    periodM: function (txts, callback) {// 创建凭证时的会计期间，不包括已经关闭的
        this.complete(txts, 1, 15, 0, function (a) {//ID,助记名,全称,拼音码,平台ID
            var c = {}
            c.label = a[1];
            c.value = a[1];
            c.id = a[0];
            c.tips = a[1]; // 额外提示信息
            c.ptid = a[1];
            c.date_start = a[2];
            c.date_stop = a[3];
            c.move_name = a[4];
            c.sequence_id = a[5];
            return c;
        }, callback, 1, 'a-account.move.period');
    },
    period: function (txts, callback) {// 智能会计期间
        this.complete(txts, 1, 15, 0, function (a) {//ID,助记名,全称,拼音码,平台ID
            var c = {}
            c.label = a[1];
            c.value = a[1];
            c.id = a[0];
            c.tips = a[1]; // 额外提示信息
            c.ptid = a[1];
            c.date_start = a[2];
            c.date_stop = a[3];
            return c;
        }, callback, 1, 'a-pzPeriod');
    },
    inventory: function (txts, callback) {// 智能会计期间
        this.complete(txts, 1, 15, 0, function (a) {//ID,助记名,全称,拼音码,平台ID
            var c = {}
            c.label = a[1];
            c.value = a[1];
            c.id = a[0];
            c.tips = a[1]; // 额外提示信息
            c.ptid = a[1];
            return c;
        }, callback, 1, 'a.stock.invertory');
    },
    complete: function (txts, type, qty, minLength, fResponse, callback, conType, code) {
        if (!conType) conType = G.con_type.auto;
        var v = false;
        $(txts).blur(function () {
            if (!$(this).val()) {
                $(this).attr('_id', '');
                if ($(this).is('[ptid]')) $(this).attr('ptid', '');
            }
        });
        $(txts).next('.oe-m2o-drop-down-button').click(function () {
            v = true;
            $(this).prev().autocomplete("search");
            $(this).prev().focus();
        });
        txts.autocomplete({
            source: function (request, response) {
                //if (ur.company().id && ur.user().id) {
                var extid = txts.attr('extid');
                if (!extid) extid = 0;
                pgf.codeData(code, [v ? '' : txts.val().trim(), txts.attr('p_id') || 0, txts.attr('j_id') || 0], function (a) {
                    v = false;
                    for (var i = 0; i < a.length; i++) a[i] = fResponse(a[i]);
                    response(a);
                }, conType);
                // }
            },
            select: function (event, ui) {
                if (ui.item.id) $(this).attr('_id', ui.item.id);
                if (ui.item.tips) $(this).attr('title', ui.item.tips);
                if (ui.item.ptid) $(this).attr('code', ui.item.ptid);
                if (ui.item.date_start) $(this).attr('date_start', ui.item.date_start);
                if (ui.item.date_stop) $(this).attr('date_stop', ui.item.date_stop);
                if ($.isFunction(callback)) callback(ui.item, this);
            },
            close: function (event, ui) {
            },
            change: function (event, ui) {
            },
            minLength: minLength,
            selectFirst: true
        });
        if (txts.size() > 0) {
            txts.data("autocomplete")._renderItem = function (ul, item) {
                var line = item.label ? "<a>" + item.label + "</a>" : '<a>无匹配条件</a>';
                return $("<li></li>")
			.data("item.autocomplete", item)
			.append($(line))
			.appendTo(ul);
            }
        }
    }
}

var o=(function ($) {

    $(".ui-autocomplete-input").live("autocompleteopen", function () {
        var autocomplete = $(this).data("autocomplete"),
		menu = autocomplete.menu;
        if (!autocomplete.options.selectFirst) {
            return;
        }
        menu.activate($.Event({ type: "mouseenter" }), menu.element.children().first());
    });

} (jQuery));


//postMessage
var pm = {
    ini: function () {
        if (typeof window.addEventListener != 'undefined') {
            window.addEventListener('message', this.onmessage, false);
        } else if (typeof window.attachEvent != 'undefined') {
            window.attachEvent('onmessage', this.onmessage);
        }
        if (window.parent && window.parent.parent)
            window.parent.parent.postMessage({ code: 'lg' }, '*');
        else
            this.enable = false;
    },
    enable: true,
    postMsg: function (d) {
        if (window.parent && window.parent.parent)
            window.parent.parent.postMessage(d, '*');
    },
    onmessage: function (e) {
        var d = e.data;
        if (d.code == 'lg' && d.data) {
            d = JSON.parse(d.data);
            if (localStorage.last_login_login_success != d.last_login_login_success || localStorage.last_db_login_success!=d.last_db_login_success) {
                localStorage.last_db_login_success = d.last_db_login_success;
                localStorage.last_login_login_success = d.last_login_login_success;

                pgf.codeData('user-cus-info', [localStorage.last_login_login_success], function (a) {
                    a = a[0];
                    localStorage.user_id = a[0];
                    localStorage.partner_id = a[1];
                    localStorage.partner_name = a[2];
                    localStorage.user_name = a[3];
                    user.id = a[0];
                    user.login = localStorage.last_login_login_success;
                    user.name = a[3];
                    //alert(localStorage.user_id);
                })
            }
            else {
                user.id = localStorage.user_id;
                user.name = localStorage.user_name;
            }
        }
    }
}